console.log("[UT] Content script loaded:", window.location.href);

// ── Extension status banner ───────────────────────────────────────────────────
(async () => {
  const { authToken } = await chrome.storage.local.get(["authToken"]);
  if (authToken) return;

  const banner = document.createElement("div");
  banner.id = "ut-status-banner";
  banner.style.cssText = [
    "position:fixed", "top:0", "left:0", "right:0", "z-index:2147483647",
    "background:#fef3c7", "border-bottom:1px solid #fcd34d",
    "padding:10px 16px", "display:flex", "align-items:center", "gap:10px",
    "font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif",
    "font-size:13px", "color:#92400e", "box-shadow:0 2px 8px rgba(0,0,0,.08)",
  ].join(";");

  banner.innerHTML = `
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0">
      <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
      <line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>
    </svg>
    <span><strong>Upwork Tracker:</strong> No token configured — click the extension icon and paste your token to start syncing.</span>
    <button id="ut-banner-close" style="margin-left:auto;background:none;border:none;cursor:pointer;font-size:16px;color:#92400e;line-height:1;padding:0 4px">✕</button>
  `;

  document.documentElement.appendChild(banner);
  document.getElementById("ut-banner-close")?.addEventListener("click", () => banner.remove());
})();

// ── Firefox fallback: inject into MAIN world via script tags ──
// Chrome uses chrome.scripting with world:"MAIN" from background.js
// Firefox doesn't support that, so we inject via script tags after a short delay
setTimeout(() => {
  if (!window.__utIntercepted) {
    console.log("[UT] MAIN world not injected by background, using script tag fallback");
    const s1 = document.createElement("script");
    s1.src = chrome.runtime.getURL("src/injected.js");
    s1.onload = () => s1.remove();
    (document.head || document.documentElement).appendChild(s1);

    const s2 = document.createElement("script");
    s2.src = chrome.runtime.getURL("src/account-detector.js");
    s2.onload = () => s2.remove();
    (document.head || document.documentElement).appendChild(s2);
  }
}, 1000);

// ── Listen for messages from MAIN world (injected.js) ──
window.addEventListener("message", (event) => {
  if (event.origin !== window.location.origin) return;

  if (event.data?.type === "UT_GQL_RESPONSE") {
    chrome.runtime.sendMessage(
      { type: "GQL_CAPTURED", payload: event.data.payload },
      (r) => { if (chrome.runtime.lastError) console.error("[UT]", chrome.runtime.lastError.message); }
    );
  }

  if (event.data?.type === "UPWORK_ACCOUNT_DETECTED") {
    console.log("[UT] Account detected via detector:", event.data.payload);
    chrome.runtime.sendMessage(
      { type: "SAVE_ACCOUNT_INFO", payload: event.data.payload },
      (r) => { if (chrome.runtime.lastError) console.error("[UT]", chrome.runtime.lastError.message); }
    );
  }

  if (event.data?.type === "UT_INITIAL_STATE") {
    try {
      const state = JSON.parse(event.data.payload);
      if (state && Object.keys(state).length > 0) {
        console.log("[UT] Got __INITIAL_STATE__");
        chrome.runtime.sendMessage({ type: "INITIAL_STATE", payload: { state, capturedAt: new Date().toISOString() } });
      }
    } catch (_) {}
  }
});

// ── Helpers ──
function extractNumber(text) {
  if (!text) return null;
  const cleaned = text.replace(/[,%$]/g, "").trim();
  const num = parseFloat(cleaned);
  return isNaN(num) ? null : num;
}

function sendToBackground(type, data) {
  console.log("[UT] Sending:", type, JSON.stringify(data).slice(0, 300));
  chrome.runtime.sendMessage({ type, payload: data }, (r) => {
    if (chrome.runtime.lastError) {
      console.error("[UT] Send error:", chrome.runtime.lastError.message);
    } else {
      console.log("[UT] Response:", JSON.stringify(r).slice(0, 200));
    }
  });
}

// ── Bidding criteria evaluation ──

const CRITERIA_FIELD_LABELS = {
  client_total_spent:      "Client Total Spent",
  client_rating:           "Client Rating",
  client_hire_rate:        "Client Hire Rate",
  client_reviews:          "Client Reviews",
  client_jobs_posted:      "Client Jobs Posted",
  client_hires:            "Client Hires",
  client_active_hires:     "Client Active Hires",
  client_payment_verified: "Payment Verified",
  client_country:          "Client Country",
  job_interviewing:        "Interviewing",
  job_proposals:           "Proposals",
  job_hires:               "Hires (this job)",
  job_last_viewed:         "Last Viewed (hours ago)",
  job_skill_match:         "Skill Match",
};

function parseCurrencyToNumber(str) {
  if (typeof str === "number") return str;
  if (!str) return null;
  const s = String(str).replace(/[$,\s+]/g, "").toUpperCase();
  const m = s.match(/^([\d.]+)([KMB]?)$/);
  if (!m) return null;
  const mult = { K: 1000, M: 1000000, B: 1000000000 }[m[2]] || 1;
  return parseFloat(m[1]) * mult;
}

function getJobFieldValue(key, job) {
  switch (key) {
    case "client_total_spent":      return parseCurrencyToNumber(job.clientSpent);
    case "client_rating":           return job.clientRating ?? null;
    case "client_hire_rate":        return job.clientHireRate ?? null;
    case "client_reviews":          return job.clientReviews ?? null;
    case "client_jobs_posted":      return job.clientJobsPosted ?? null;
    case "client_hires":            return job.clientHires ?? null;
    case "client_active_hires":     return job.clientActiveHires ?? null;
    case "client_payment_verified": return job.clientPaymentVerified ?? null;
    case "client_country":          return job.clientCountry ?? null;
    case "job_interviewing":        return job.interviewing ?? null;
    case "job_proposals":           return job.jobProposals ?? null;
    case "job_hires":               return job.jobHires ?? null;
    case "job_last_viewed":         return job.lastViewedHours ?? null;
    case "job_skill_match":         return job.skillMatchCount ?? null;
    default:                        return null;
  }
}

function checkCriterion(criterion, job) {
  const actual = getJobFieldValue(criterion.key, job);
  if (actual === null || actual === undefined) return "unknown";
  if (criterion.key === "client_payment_verified") return actual === true ? "pass" : "fail";
  if (criterion.key === "client_country") {
    const blocked = criterion.value.split(",").map((s) => s.trim().toLowerCase()).filter(Boolean);
    const matches = blocked.some((b) => b === String(actual).toLowerCase());
    return criterion.operator === "neq" ? (matches ? "fail" : "pass") : (matches ? "pass" : "fail");
  }
  const threshold = parseFloat(criterion.value);
  if (isNaN(threshold)) return "unknown";
  const pass = criterion.operator === "gte" ? actual >= threshold
             : criterion.operator === "lte" ? actual <= threshold
             : criterion.operator === "neq" ? actual !== threshold
             : actual === threshold;
  return pass ? "pass" : "fail";
}

function formatCriterionLabel(c) {
  const label = CRITERIA_FIELD_LABELS[c.key] || c.key;
  if (c.key === "client_payment_verified") return label;
  if (c.key === "client_country") {
    const countries = c.value.split(",").map((s) => s.trim()).filter(Boolean);
    return `${label} ≠ ${countries.join(", ")}`;
  }
  const op = c.operator === "gte" ? "≥" : c.operator === "lte" ? "≤" : c.operator === "neq" ? "≠" : "=";
  const val = c.key === "client_total_spent" ? `$${Number(c.value).toLocaleString()}`
            : c.key === "client_hire_rate"   ? `${c.value}%`
            : c.key === "client_rating"      ? `${c.value}/5`
            : c.value;
  return `${label} ${op} ${val}`;
}

async function evaluateAndShowCriteria(job, isRetry = false) {
  try {
    const data = await new Promise((resolve) => chrome.runtime.sendMessage({ type: "GET_BIDDING_CRITERIA" }, resolve));
    const criteria = (data && data.criteria) || [];
    if (criteria.length === 0) return;

    // Compute skill match count if the criterion is configured
    if (criteria.some((c) => c.key === "job_skill_match")) {
      const profile = await getFreelancerProfile();
      const freelancerSkills = profile?.skills || [];
      const jobSkills = job.skills || [];
      const freelancerLower = new Set(freelancerSkills.map((s) => s.toLowerCase()));
      job.skillMatchCount = jobSkills.filter((s) => freelancerLower.has(s.toLowerCase())).length;
      console.log("[UT] Skill match:", job.skillMatchCount, "/", jobSkills.length,
        "— job:", jobSkills, "freelancer:", freelancerSkills);
    }

    const results = criteria.map((c) => ({ ...c, status: checkCriterion(c, job) }));
    injectCriteriaPanel(job, results, isRetry);

    // If required criteria are still unknown and this isn't already a retry,
    // re-scrape after a delay to pick up lazily-loaded client data
    const hasRequiredUnknown = results.some((r) => r.required && r.status === "unknown");
    if (hasRequiredUnknown && !isRetry) {
      const jobUrlSnapshot = job.url;
      setTimeout(async () => {
        try {
          // Only retry if the same job panel is still open
          if (!isJobPanelOpen()) return;
          const currentUrl = findJobUrl(findJobContainer());
          if (currentUrl !== jobUrlSnapshot) return;
          const retryJob = await scrapeJobData();
          if (retryJob?.title) evaluateAndShowCriteria(retryJob, true).catch(() => {});
        } catch (e) { console.warn("[UT] criteria retry error:", e); }
      }, 5000);
    }
  } catch (e) {
    console.warn("[UT] evaluateAndShowCriteria error:", e);
  }
}

function buildChatGPTPrompt(job, results, profile) {
  const line = (label, val) => val != null && val !== "" ? `- **${label}:** ${val}` : null;
  const yesNo = (v) => v === true ? "Yes" : v === false ? "No" : "Unknown";

  const jobLines = [
    line("Title",             job.title),
    line("Type",              job.jobType),
    line("Budget",            job.budget),
    line("Experience Level",  job.experienceLevel),
    line("Posted",            job.postedTime),
    line("Location",          job.jobLocation || "Worldwide"),
    line("Connects Required", job.connectsRequired),
    line("Project Type",      job.projectType),
    line("Contract-to-Hire",  job.contractToHire ? "Yes" : null),
  ].filter(Boolean).join("\n");

  const clientLines = [
    line("Payment Verified",  yesNo(job.clientPaymentVerified)),
    line("Rating",            job.clientRating ? `${job.clientRating}/5` : null),
    line("Reviews",           job.clientReviews),
    line("Country",           job.clientCountry),
    line("Total Spent",       job.clientSpent),
    line("Hire Rate",         job.clientHireRate != null ? `${job.clientHireRate}%` : null),
    line("Jobs Posted",       job.clientJobsPosted),
    line("Hires",             job.clientHires),
    line("Active Hires",      job.clientActiveHires),
    line("Industry",          job.clientIndustry),
    line("Company Size",      job.clientCompanySize),
    line("Member Since",      job.clientMemberSince),
  ].filter(Boolean).join("\n");

  const activityLines = [
    line("Proposals",             job.jobProposals    != null ? String(job.jobProposals)              : null),
    line("Interviewing",          job.interviewing    != null ? String(job.interviewing)               : null),
    line("Hires (this job)",      job.jobHires        != null ? String(job.jobHires)                   : null),
    line("Last Viewed by Client", job.lastViewedHours != null ? `${job.lastViewedHours} hour(s) ago`   : null),
  ].filter(Boolean).join("\n");

  const skillsList = job.skills?.length ? job.skills.join(", ") : "Not listed";

  const verdictResult = (() => {
    const reqFailed  = results.filter((r) => r.required && r.status === "fail");
    const reqUnknown = results.filter((r) => r.required && r.status === "unknown");
    if (reqFailed.length > 0) return "Not Recommended";
    if (reqUnknown.length > 0) return "Uncertain (some required data not visible)";
    return "Worth Applying";
  })();

  const criteriaLines = results.map((r) => {
    const icon = r.status === "pass" ? "✓" : r.status === "fail" ? "✗" : "?";
    return `${icon} ${formatCriterionLabel(r)}${r.required ? " [required]" : ""}: ${r.status.toUpperCase()}`;
  }).join("\n");

  const profileLines = profile ? [
    profile.name       ? `**Name:** ${profile.name}` : null,
    profile.title      ? `**Title:** ${profile.title}` : null,
    profile.skills?.length ? `**Skills:** ${profile.skills.join(", ")}` : null,
    profile.overview   ? `**Overview:** ${profile.overview.slice(0, 600)}` : null,
    profile.hourlyRate ? `**Hourly Rate:** ${profile.hourlyRate}/hr` : null,
    profile.totalJobs  ? `**Total Jobs Completed:** ${profile.totalJobs}` : null,
    profile.jss        ? `**Job Success Score:** ${profile.jss}%` : null,
  ].filter(Boolean) : [];
  const profileSection = profileLines.length > 0
    ? profileLines.join("\n")
    : "_Profile not loaded yet. Visit your Upwork profile page once so the extension can load your skills._";

  return `You are an unbiased Upwork bidding advisor. Your job is to give an honest, objective assessment of whether this freelancer should bid on this job. Do NOT lean toward recommending just to be encouraging — if the job looks bad, say so clearly.

---

## JOB DETAILS

${jobLines}

**Description:**
${job.description || "Not available"}

**Required Skills:** ${skillsList}

## CLIENT INFO

${clientLines || "Not available"}

## JOB ACTIVITY

${activityLines || "Not available"}

**Job URL:** ${job.url || "N/A"}

## FREELANCER PROFILE

${profileSection}

## PRE-CHECKED CRITERIA (system verdict: ${verdictResult})

${criteriaLines || "No criteria configured"}

---

## YOUR TASK

Analyze everything above and answer: **Should this freelancer bid on this job?**

**Your response MUST start with one of these lines exactly:**
> ✅ RECOMMENDED — [one-line reason]
> ❌ NOT RECOMMENDED — [one-line reason]
> ⚠️ MAYBE — [one-line reason]

Then provide a brief breakdown covering:
1. **Skill match** — how well does the freelancer's background fit the job?
2. **Client reliability** — what does the client's history say (payment verified, rating, spend, hire rate)?
3. **Competition level** — is the proposal/interviewing count favorable or crowded?
4. **Budget vs scope** — is the pay realistic for the work described?
5. **Client engagement** — when did the client last view the job? Are they active?
6. **Red flags** — anything suspicious or risky?
7. **Green flags** — anything that makes this a strong opportunity?

Be direct and honest. If the job is not a good fit, say so. The freelancer is relying on your honest opinion to make a good decision.`;
}

function injectCriteriaPanel(job, results, isRetry = false) {
  document.getElementById("ut-criteria-panel")?.remove();

  const requiredFailed    = results.filter((r) => r.required && r.status === "fail");
  const requiredUnknown   = results.filter((r) => r.required && r.status === "unknown");
  const hasUnknown        = results.some((r) => r.status === "unknown");
  // After retry, persistent unknowns are treated as not available — don't block the verdict
  const allRequiredPassed = requiredFailed.length === 0 && (isRetry || requiredUnknown.length === 0);
  const stillLoading      = !isRetry && requiredFailed.length === 0 && requiredUnknown.length > 0;

  const verdictColor = stillLoading ? "#92400e" : allRequiredPassed ? "#108a00" : "#dc2626";
  const verdictLabel = stillLoading ? "⏳ Loading client data..." : allRequiredPassed ? "✓ Worth applying" : "✗ Not recommended";
  const verdictBg    = stillLoading ? "#fffbeb" : allRequiredPassed ? "#f0fdf4" : "#fef2f2";

  const rows = results.map((r) => {
    const icon       = r.status === "pass" ? "✓" : r.status === "fail" ? "✗" : "?";
    const iconColor  = r.status === "pass" ? "#108a00" : r.status === "fail" ? "#dc2626" : "#9ca3af";
    const labelColor = r.status === "fail" && r.required ? "#dc2626" : "#374151";
    return `
      <div style="display:flex;align-items:center;gap:10px;padding:8px 14px;border-bottom:1px solid #f3f4f6;">
        <span style="font-size:14px;font-weight:700;color:${iconColor};width:16px;text-align:center;flex-shrink:0;">${icon}</span>
        <div style="flex:1;min-width:0;">
          <div style="font-size:12px;font-weight:${r.required ? "600" : "400"};color:${labelColor};white-space:nowrap;overflow:hidden;text-overflow:ellipsis;" title="${formatCriterionLabel(r)}">${formatCriterionLabel(r)}</div>
          ${r.status === "unknown" ? '<div style="font-size:11px;color:#9ca3af;">Not visible on page</div>' : ""}
        </div>
        ${r.required ? '<span style="font-size:10px;color:#6b7280;background:#f3f4f6;padding:1px 5px;border-radius:4px;flex-shrink:0;">req</span>' : ""}
      </div>`;
  }).join("");

  const panel = document.createElement("div");
  panel.id = "ut-criteria-panel";
  panel.setAttribute("style", [
    "position:fixed", "right:20px", "bottom:20px", "width:300px",
    "background:#fff", "color:#0e1925", "border:1px solid #d5dde5", "border-radius:12px",
    "box-shadow:0 10px 40px rgba(14,25,37,0.18)", "z-index:2147483647",
    "font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif",
    "overflow:hidden",
  ].join(";"));

  panel.innerHTML = `
    <div id="ut-criteria-header" style="display:flex;align-items:center;justify-content:space-between;padding:10px 14px;background:${verdictBg};border-bottom:1px solid #e5e7eb;cursor:move;">
      <div style="font-weight:700;font-size:13px;color:${verdictColor};">${verdictLabel}</div>
      <button id="ut-criteria-close" style="background:transparent;color:#9ca3af;border:0;cursor:pointer;font-size:16px;line-height:1;padding:0 4px;">✕</button>
    </div>
    <div style="max-height:280px;overflow-y:auto;">${rows}</div>
    ${hasUnknown ? '<div style="padding:7px 14px;font-size:11px;color:#9ca3af;border-top:1px solid #f3f4f6;">? = client data not shown on this page</div>' : ""}
    <div style="padding:10px 14px;border-top:1px solid #f3f4f6;">
      <button id="ut-chatgpt-btn" style="width:100%;display:flex;align-items:center;justify-content:center;gap:7px;padding:8px 12px;background:#10a37f;color:#fff;border:0;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;font-family:inherit;transition:opacity 0.15s;">
        <svg width="14" height="14" viewBox="0 0 41 41" fill="none" xmlns="http://www.w3.org/2000/svg" style="flex-shrink:0;"><path d="M37.532 16.87a9.963 9.963 0 0 0-.856-8.184 10.078 10.078 0 0 0-10.855-4.835 9.964 9.964 0 0 0-6.215-3.807 10.079 10.079 0 0 0-11.136 4.964 9.963 9.963 0 0 0-6.62 4.827 10.079 10.079 0 0 0 1.24 11.817 9.965 9.965 0 0 0 .856 8.185 10.079 10.079 0 0 0 10.855 4.835 9.965 9.965 0 0 0 6.215 3.806 10.079 10.079 0 0 0 11.136-4.964 9.963 9.963 0 0 0 6.62-4.827 10.079 10.079 0 0 0-1.24-11.817zm-17.851 16.51a7.461 7.461 0 0 1-4.778-1.719l.236-.134 7.938-4.578a.652.652 0 0 0 .33-.573v-11.19l3.354 1.936a.061.061 0 0 1 .033.048v9.268c-.004 4.135-3.355 7.482-7.113 7.482zm-15.261-6.866a7.431 7.431 0 0 1-.889-5.023l.236.142 7.938 4.578a.648.648 0 0 0 .659 0l9.702-5.604v3.872a.064.064 0 0 1-.026.053l-8.026 4.631c-3.582 2.073-8.162.84-9.594-2.65zm-1.99-17.619a7.447 7.447 0 0 1 3.886-3.275V16.8a.651.651 0 0 0 .329.572l9.703 5.604-3.354 1.935a.061.061 0 0 1-.06.006l-8.027-4.632a7.482 7.482 0 0 1-2.477-9.38zm27.372 6.42l-9.703-5.604 3.354-1.935a.06.06 0 0 1 .06-.007l8.027 4.633a7.479 7.479 0 0 1-1.158 13.528v-9.645a.651.651 0 0 0-.58-.97zm3.34-5.053-.236-.141-7.938-4.578a.65.65 0 0 0-.659 0l-9.702 5.604v-3.872a.063.063 0 0 1 .025-.053l8.027-4.632a7.481 7.481 0 0 1 11.483 7.672zm-21.01 6.921l-3.354-1.935a.062.062 0 0 1-.034-.048V7.926a7.481 7.481 0 0 1 12.264-5.738l-.236.134-7.938 4.578a.651.651 0 0 0-.33.572l-.012 11.19-.36-.207zm1.822-3.93l4.322-2.492 4.322 2.49v4.983l-4.322 2.491-4.322-2.49V13.384z" fill="currentColor"/></svg>
        Ask ChatGPT
      </button>
    </div>
  `;

  document.body.appendChild(panel);

  // Drag
  const header = panel.querySelector("#ut-criteria-header");
  let dragging = false, offX = 0, offY = 0;
  header.addEventListener("mousedown", (e) => {
    if (e.target.tagName === "BUTTON") return;
    dragging = true;
    const rect = panel.getBoundingClientRect();
    offX = e.clientX - rect.left;
    offY = e.clientY - rect.top;
    e.preventDefault();
  });
  document.addEventListener("mousemove", (e) => {
    if (!dragging) return;
    panel.style.left   = (e.clientX - offX) + "px";
    panel.style.top    = (e.clientY - offY) + "px";
    panel.style.right  = "auto";
    panel.style.bottom = "auto";
  });
  document.addEventListener("mouseup", () => { dragging = false; });

  panel.querySelector("#ut-criteria-close").addEventListener("click", () => panel.remove());

  panel.querySelector("#ut-chatgpt-btn").addEventListener("click", async () => {
    const btn = panel.querySelector("#ut-chatgpt-btn");
    btn.textContent = "Building prompt…";
    btn.disabled = true;
    btn.style.opacity = "0.7";
    try {
      const profile = await getFreelancerProfile();
      const prompt = buildChatGPTPrompt(job, results, profile);
      await navigator.clipboard.writeText(prompt);
      btn.textContent = "✓ Copied! Opening ChatGPT…";
      setTimeout(() => {
        window.open("https://chatgpt.com/", "_blank");
        btn.innerHTML = `<svg width="14" height="14" viewBox="0 0 41 41" fill="none" xmlns="http://www.w3.org/2000/svg" style="flex-shrink:0;"><path d="M37.532 16.87a9.963 9.963 0 0 0-.856-8.184 10.078 10.078 0 0 0-10.855-4.835 9.964 9.964 0 0 0-6.215-3.807 10.079 10.079 0 0 0-11.136 4.964 9.963 9.963 0 0 0-6.62 4.827 10.079 10.079 0 0 0 1.24 11.817 9.965 9.965 0 0 0 .856 8.185 10.079 10.079 0 0 0 10.855 4.835 9.965 9.965 0 0 0 6.215 3.806 10.079 10.079 0 0 0 11.136-4.964 9.963 9.963 0 0 0 6.62-4.827 10.079 10.079 0 0 0-1.24-11.817zm-17.851 16.51a7.461 7.461 0 0 1-4.778-1.719l.236-.134 7.938-4.578a.652.652 0 0 0 .33-.573v-11.19l3.354 1.936a.061.061 0 0 1 .033.048v9.268c-.004 4.135-3.355 7.482-7.113 7.482zm-15.261-6.866a7.431 7.431 0 0 1-.889-5.023l.236.142 7.938 4.578a.648.648 0 0 0 .659 0l9.702-5.604v3.872a.064.064 0 0 1-.026.053l-8.026 4.631c-3.582 2.073-8.162.84-9.594-2.65zm-1.99-17.619a7.447 7.447 0 0 1 3.886-3.275V16.8a.651.651 0 0 0 .329.572l9.703 5.604-3.354 1.935a.061.061 0 0 1-.06.006l-8.027-4.632a7.482 7.482 0 0 1-2.477-9.38zm27.372 6.42l-9.703-5.604 3.354-1.935a.06.06 0 0 1 .06-.007l8.027 4.633a7.479 7.479 0 0 1-1.158 13.528v-9.645a.651.651 0 0 0-.58-.97zm3.34-5.053-.236-.141-7.938-4.578a.65.65 0 0 0-.659 0l-9.702 5.604v-3.872a.063.063 0 0 1 .025-.053l8.027-4.632a7.481 7.481 0 0 1 11.483 7.672zm-21.01 6.921l-3.354-1.935a.062.062 0 0 1-.034-.048V7.926a7.481 7.481 0 0 1 12.264-5.738l-.236.134-7.938 4.578a.651.651 0 0 0-.33.572l-.012 11.19-.36-.207zm1.822-3.93l4.322-2.492 4.322 2.49v4.983l-4.322 2.491-4.322-2.49V13.384z" fill="currentColor"/></svg> Ask ChatGPT`;
        btn.disabled = false;
        btn.style.opacity = "1";
      }, 800);
    } catch (e) {
      console.error("[UT] ChatGPT prompt error:", e);
      btn.textContent = "Failed — try again";
      btn.disabled = false;
      btn.style.opacity = "1";
    }
  });
}

// ── Feed card verdicts ────────────────────────────────────────────────────────
// Shows a small ✓/✗/? badge on every job card in the feed.
// Evaluated locally from the 3 fields visible on cards: payment verified,
// rating, and total spent. Criteria loaded via the backend API (same call the
// sidebar uses), then cached in chrome.storage for 5 minutes so subsequent
// page loads don't hit the network at all.

const CARD_EVALUABLE_FIELDS = new Set([
  "client_payment_verified",
  "client_rating",
  "client_total_spent",
  "client_country",
  "job_proposals",
]);

let _cardCriteriaCache = null;
let _cardCriteriaTs    = 0;
let _cardCriteriaHash  = "";

let _freelancerProfileCache = null;
let _freelancerProfileTs    = 0;

async function getFreelancerProfile() {
  if (!isContextValid()) return null;
  const now = Date.now();
  if (_freelancerProfileCache && now - _freelancerProfileTs < 300_000) {
    return _freelancerProfileCache;
  }
  try {
    const data = await new Promise((resolve) =>
      chrome.runtime.sendMessage({ type: "GET_FREELANCER_PROFILE" }, resolve)
    );
    _freelancerProfileCache = data?.profile || null;
    _freelancerProfileTs    = now;
    return _freelancerProfileCache;
  } catch (e) {
    return _freelancerProfileCache; // return stale on error
  }
}

function _criteriaHash(criteria) {
  return criteria.map((c) => `${c.id}:${c.key}:${c.operator}:${c.value}:${c.required}`).join("|");
}

async function loadCardCriteria() {
  if (!isContextValid()) return [];

  const now = Date.now();

  // 1. In-memory cache (15s) — fast path, short enough to pick up admin changes quickly
  if (_cardCriteriaCache && now - _cardCriteriaTs < 15_000) {
    return _cardCriteriaCache;
  }

  try {
    // 2. chrome.storage cache (60s TTL) — survives page loads, refreshes within a minute of admin changes
    const stored = await chrome.storage.local.get(["_criteriaCache", "_criteriaCacheTs"]);
    if (stored._criteriaCache && now - (stored._criteriaCacheTs || 0) < 60_000) {
      const incoming = stored._criteriaCache;
      const incomingHash = _criteriaHash(incoming);
      if (incomingHash !== _cardCriteriaHash) {
        document.querySelectorAll(".ut-verdict-badge").forEach((b) => b.remove());
        _cardCriteriaHash = incomingHash;
        console.log("[UT] Criteria changed (storage), clearing badges");
      }
      _cardCriteriaCache = incoming;
      _cardCriteriaTs    = now;
      console.log("[UT] Criteria: storage cache hit,", _cardCriteriaCache.length, "criteria");
      return _cardCriteriaCache;
    }

    // 3. Fetch from backend via background (same endpoint the sidebar uses)
    console.log("[UT] Criteria: fetching from API...");
    const data = await new Promise((resolve) =>
      chrome.runtime.sendMessage({ type: "GET_BIDDING_CRITERIA" }, resolve)
    );
    const incoming = (data && data.criteria) || [];
    const incomingHash = _criteriaHash(incoming);
    if (incomingHash !== _cardCriteriaHash) {
      document.querySelectorAll(".ut-verdict-badge").forEach((b) => b.remove());
      _cardCriteriaHash = incomingHash;
      console.log("[UT] Criteria changed (API), clearing badges —",
        incoming.map((c) => `${c.key}(req:${c.required})`).join(", "));
    }
    _cardCriteriaCache = incoming;
    _cardCriteriaTs    = now;

    chrome.storage.local.set({ _criteriaCache: _cardCriteriaCache, _criteriaCacheTs: now }).catch(() => {});

    return _cardCriteriaCache;
  } catch (e) {
    // Extension context invalidated (reloaded/updated) — stop silently
    return [];
  }
}

function parseProposalRange(str) {
  if (!str) return null;
  const ltM    = str.match(/(?:less|fewer)\s*than\s*(\d+)/i);
  const rangeM = str.match(/(\d+)\s*to\s*(\d+)/i);
  const plusM  = str.match(/(\d+)\+/);
  const exactM = str.match(/^(\d+)$/);
  if (ltM)    return parseInt(ltM[1]) - 1;       // "Less than 5" → 4
  if (rangeM) return parseInt(rangeM[2]);         // "5 to 10" → 10
  if (plusM)  return parseInt(plusM[1]) + 50;     // "50+" → 100
  if (exactM) return parseInt(exactM[1]);
  return null;
}

function parseLastViewed(str) {
  if (!str) return null;
  const s = str.toLowerCase().trim();
  if (s === "just now")  return 0;
  if (s === "yesterday") return 24;
  const minM   = s.match(/(\d+)\s*minute/);
  if (minM)  return 0;                                    // < 1 hour → 0
  const hourM  = s.match(/(\d+)\s*hour/);
  if (hourM) return parseInt(hourM[1]);                   // "3 hours ago" → 3
  const dayM   = s.match(/(\d+)\s*day/);
  if (dayM)  return parseInt(dayM[1]) * 24;               // "2 days ago" → 48
  const weekM  = s.match(/(\d+)\s*week/);
  if (weekM) return parseInt(weekM[1]) * 168;             // "1 week ago" → 168
  const monthM = s.match(/(\d+)\s*month/);
  if (monthM) return parseInt(monthM[1]) * 720;           // "2 months ago" → 1440
  return null;
}

function scrapeCardClientData(card) {
  const text = card.innerText || "";
  const data = {};

  // ── Payment verified ──
  data.clientPaymentVerified = /payment\s*(method\s*)?verified/i.test(text);

  // ── Rating — look for a decimal like "4.8" near star elements ──
  const starEl = card.querySelector(
    '[class*="star"], [class*="rating"], [class*="stars"], [aria-label*="star"], [aria-label*="rating"]'
  );
  if (starEl) {
    const rt = (starEl.closest("div, span, li") || starEl).textContent || "";
    const rm = rt.match(/\b([1-5](?:\.\d{1,2})?)\b/);
    if (rm) data.clientRating = parseFloat(rm[1]);
  }
  if (!data.clientRating) {
    const rm = text.match(/\b([1-5]\.\d{1,2})\b/);
    if (rm) data.clientRating = parseFloat(rm[1]);
  }

  // ── Spent — "$1K+ spent", "$30K+ spent", "$5.2M spent" ──
  const sm = text.match(/\$([\d,.]+[KkMmBb]*\+?)\s*(?:total\s*)?spent/i);
  if (sm) data.clientSpent = "$" + sm[1];

  // ── Country — word(s) after "spent" on the same or next line ──
  const cm = text.match(/\bspent[\s\S]{0,10}\n\s*([A-Z][a-zA-Z ()]{2,40})\s*(?:\n|$)/m)
          || text.match(/\bspent\s+([A-Z][a-zA-Z ()]{2,40})\s*(?:\n|$)/m);
  if (cm) data.clientCountry = cm[1].trim();

  // ── Proposals — "Proposals: Less than 5", "Proposals: 5 to 10", etc. ──
  // Require the colon and anchor to a line start to avoid matching "proposal" in job descriptions.
  const pm = text.match(/(?:^|\n)\s*proposals?\s*:\s*([^\n]{1,30})/i);
  if (pm) data.jobProposals = parseProposalRange(pm[1].trim());

  console.log("[UT] Card scraped:", {
    paymentVerified: data.clientPaymentVerified,
    rating:          data.clientRating,
    spent:           data.clientSpent,
    country:         data.clientCountry,
    proposals:       data.jobProposals,
    text:            text.slice(0, 300).replace(/\n/g, " | "),
  });
  return data;
}

function computeCardVerdict(cardData, criteria) {
  const applicable = criteria.filter((c) => CARD_EVALUABLE_FIELDS.has(c.key));
  if (!applicable.length) return null;

  const results    = applicable.map((c) => ({ ...c, status: checkCriterion(c, cardData) }));
  const reqFailed  = results.filter((r) => r.required && r.status === "fail");
  const reqUnknown = results.filter((r) => r.required && r.status === "unknown");
  const allReqPass = reqFailed.length === 0 && reqUnknown.length === 0;

  console.log("[UT] Card verdict:",
    results.map((r) => `${r.key}=${r.status}(req:${r.required})`).join(", "),
    "→", reqFailed.length ? "SKIP" : allReqPass ? "APPLY" : "UNKNOWN"
  );
  return { results, reqFailed, reqUnknown, allReqPass };
}

function renderCardVerdictBadge(card, verdict) {
  card.querySelector(".ut-verdict-badge")?.remove();

  let label, color, bg, border;
  if (verdict.reqFailed.length > 0) {
    label = "✗ Not Recommended"; color = "#dc2626"; bg = "#fef2f2"; border = "#fecaca";
  } else if (verdict.allReqPass) {
    label = "✓ Worth Applying";  color = "#108a00"; bg = "#f0fdf4"; border = "#bbf7d0";
  } else {
    label = "? Limited Data";    color = "#92400e"; bg = "#fffbeb"; border = "#fde68a";
  }

  const tooltip = verdict.results
    .map((r) => `${r.required ? "[req] " : ""}${formatCriterionLabel(r)}: ${r.status}`)
    .join("\n");

  const badge = document.createElement("span");
  badge.className   = "ut-verdict-badge";
  badge.title       = tooltip;
  badge.style.cssText = [
    `background:${bg}`, `color:${color}`, `border:1px solid ${border}`,
    "position:absolute", "top:7px", "right:7px",
    "display:inline-flex", "align-items:center",
    "padding:3px 10px", "border-radius:4px",
    "font-size:11px", "font-weight:700", "line-height:1.6",
    "font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif",
    "white-space:nowrap", "cursor:default", "z-index:10",
    "pointer-events:none",
  ].join(";");
  badge.textContent = label;

  // Card must be position:relative for absolute child to work
  const existingPosition = getComputedStyle(card).position;
  if (existingPosition === "static") card.style.position = "relative";

  card.appendChild(badge);
  console.log("[UT] Badge placed top-right of card");
}

let _cardVerdictObserverStarted = false;
let _cardVerdictDebounce        = null;

// Find job card containers in the feed using multiple strategies.
// Upwork NX uses React routing — card title links do NOT use /jobs/~... hrefs,
// so we cannot rely on link href patterns. Instead we locate cards by their
// client-info content (payment verified / spent amount) which is unique to cards.
function findFeedJobCards() {
  // Identify the actual job-detail drawer (the one with "Send a proposal" / "Apply now").
  // [class*="panel"] is too broad — Upwork's search results container also has "panel"
  // in its class, which would filter out every search result card.
  const jobDetailPanel = (() => {
    for (const p of document.querySelectorAll('[class*="drawer"],[role="dialog"],[class*="slider"]')) {
      if (p.offsetHeight > 200 && /Send a proposal|Apply now/i.test(p.innerText || "")) return p;
    }
    return null;
  })();
  const inPanel = (el) => !!jobDetailPanel?.contains(el);

  const cards = new Set();

  const PV_RE   = /payment\s*(?:method\s*)?(?:un)?verified/i;
  const PV_RE_G = /payment\s*(?:method\s*)?(?:un)?verified/gi;

  // Collect text nodes containing "payment verified" for Strategy 2 walk-up
  const pvTextNodes = [];
  {
    const tw = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null);
    let tn;
    while ((tn = tw.nextNode())) {
      if (PV_RE.test(tn.textContent || "")) pvTextNodes.push(tn);
    }
  }

  // ── Strategy 1: <article> elements with payment/spent info ──
  for (const el of document.querySelectorAll("article")) {
    if (inPanel(el)) continue;
    const t = el.innerText || "";
    if (t.length > 80 && /payment\s*(un)?verified|\$[\d,.]+[KkMmBb]*\+?\s*spent/i.test(t)) {
      cards.add(el);
    }
  }
  console.log("[UT] Strategy 1 (article):", cards.size);

  // ── Strategy 2: walk up from text nodes containing "payment verified"
  // Uses the pvTextNodes already collected by the TreeWalker above — works on both
  // the feed page and the search page regardless of how text is distributed in the DOM.
  if (cards.size === 0) {
    for (const tn of pvTextNodes) {
      const pvEl = tn.parentElement;
      if (!pvEl || inPanel(pvEl)) continue;
      let el = pvEl;
      let bestCard = null;
      while (el && el !== document.body) {
        const text = el.innerText || "";
        const pvCount = (text.match(PV_RE_G) || []).length;
        if (pvCount > 1) break;
        if (text.length > 80 && el.querySelector("h1, h2, h3, h4, a")) {
          bestCard = el;
        }
        el = el.parentElement;
      }
      if (bestCard && !inPanel(bestCard)) cards.add(bestCard);
    }
    console.log("[UT] Strategy 2 (text node walk-up):", cards.size);
  }

  // ── Strategy 3: job title links (traditional /jobs/~ OR /jobs/ pattern) ──
  if (cards.size === 0) {
    for (const link of document.querySelectorAll('a[href*="/jobs/~"], a[href*="/jobs/"]')) {
      if (isBadTitle(link.textContent.trim()) || inPanel(link)) continue;
      const card = link.closest(
        "article, section, [class*='card'], [class*='tile'], [class*='job'], div[class]"
      );
      if (card && (card.innerText || "").length > 80) cards.add(card);
    }
    console.log("[UT] Strategy 3 (job links):", cards.size);
  }

  // ── Strategy 4: any block element containing exactly one payment-verified block ──
  if (cards.size === 0) {
    for (const el of document.querySelectorAll("li, section, div[class], [class*='job-tile'], [class*='JobTile'], [class*='job-card']")) {
      if (inPanel(el)) continue;
      const text = el.innerText || "";
      if (text.length < 100 || text.length > 8000) continue;
      const pvCount = (text.match(PV_RE_G) || []).length;
      if (pvCount !== 1) continue;
      if (!el.querySelector("h1, h2, h3, h4, a")) continue;
      cards.add(el);
    }
    console.log("[UT] Strategy 4 (block + payment):", cards.size);
  }

  // ── Deduplicate: remove cards that are ancestors of other found cards ──
  const cardArr = [...cards];
  const deduped = cardArr.filter((c) => !cardArr.some((other) => other !== c && c.contains(other)));
  if (deduped.length !== cardArr.length) {
    console.log("[UT] Deduped:", cardArr.length, "→", deduped.length);
  }
  return deduped;
}

async function injectFeedCardVerdicts() {
  const criteria = await loadCardCriteria().catch((e) => {
    console.error("[UT] loadCardCriteria error:", e);
    return [];
  });

  const applicable = criteria.filter((c) => CARD_EVALUABLE_FIELDS.has(c.key));
  if (!applicable.length) {
    console.log("[UT] No card-evaluable criteria — skipping badges.",
      "Configured:", criteria.map((c) => c.key).join(", ") || "(none)",
      "— need one of:", [...CARD_EVALUABLE_FIELDS].join(", ")
    );
    return;
  }

  const feedCards = findFeedJobCards();
  let injected = 0;

  console.log("[UT] injectFeedCardVerdicts: found", feedCards.length, "cards,",
    applicable.length, "card-evaluable criteria");

  for (const card of feedCards) {
    if (card.querySelector(".ut-verdict-badge")) continue;
    const cardData = scrapeCardClientData(card);
    const verdict  = computeCardVerdict(cardData, criteria);
    if (verdict) {
      renderCardVerdictBadge(card, verdict);
      injected++;
    }
  }
  console.log("[UT] Feed card verdicts done: injected", injected, "of", feedCards.length, "cards");
}

function watchForFeedCardVerdicts() {
  if (_cardVerdictObserverStarted) return;
  _cardVerdictObserverStarted = true;
  console.log("[UT] watchForFeedCardVerdicts started");

  injectFeedCardVerdicts();

  const observer = new MutationObserver(() => {
    clearTimeout(_cardVerdictDebounce);
    _cardVerdictDebounce = setTimeout(() => {
      if (!isContextValid()) { observer.disconnect(); return; }
      injectFeedCardVerdicts().catch((e) =>
        console.error("[UT] injectFeedCardVerdicts error:", e)
      );
    }, 800);
  });
  observer.observe(document.body, { childList: true, subtree: true });
}

// ── Bad titles to always skip ──
const BAD_TITLES = [
  "open job in a new window", "open job", "my proposals", "my stats",
  "find work", "saved jobs", "send a proposal", "submit a proposal",
  "learn more", "upgrade", "contract-to-hire", "similar jobs",
  "apply now", "save job", "view profile", "sign in", "log in",
  "messages", "help", "settings", "view job posting", "view job",
  "proposal details", "job details", "insights",
  "search for jobs", "manage your profile", "browse jobs", "find a job",
  "post a job", "manage finances", "reports",
];

function isBadTitle(text) {
  const lower = text.toLowerCase().trim();
  if (lower.length < 5) return true;
  if (BAD_TITLES.some((bad) => lower === bad || lower.includes(bad))) return true;
  if (lower.startsWith("http")) return true;
  return false;
}

// ── Extract userId from various sources ──
// Only accept the freelancer ciphertext format (01 + ≥14 hex chars).
// Reject Upwork's short numeric internal IDs (e.g. "162" from cookies).
function extractUserId() {
  const isFreelancerId = (id) => /^~?01[a-f0-9]{14,}$/i.test(String(id || ""));
  const clean = (id) => String(id).replace(/^~/, "");

  // 1. Profile URL: /freelancers/~01f1419b6ce5c07b08
  const m1 = window.location.href.match(/\/freelancers\/~(\w+)/);
  if (m1 && isFreelancerId(m1[1])) return clean(m1[1]);

  // 2. Profile link anywhere in DOM (top-nav avatar dropdown, etc.)
  const link = document.querySelector('a[href*="/freelancers/~"]');
  if (link) {
    const m2 = link.href.match(/\/freelancers\/~(\w+)/);
    if (m2 && isFreelancerId(m2[1])) return clean(m2[1]);
  }

  // 3. Meta tag — only if ciphertext-shaped
  const meta = document.querySelector('meta[name="user-id"]');
  if (meta?.content && isFreelancerId(meta.content)) return clean(meta.content);

  // 4. Script tags — match the ciphertext specifically
  const scripts = document.querySelectorAll('script[type="application/json"], script:not([src])');
  for (const script of scripts) {
    const text = script.textContent;
    if (!text) continue;
    const m = text.match(/"(?:ciphertext|freelancerId)"\s*:\s*"~?(01[a-f0-9]{14,})"/i);
    if (m) return m[1];
  }

  // No cookie fallback — returns wrong-format internal IDs (e.g. "162")
  return null;
}

// ── Profile scrape retry state ──
let _profileScrapeTimer   = null;
let _profileScrapeAttempt = 0;
// Retry delays (ms): 0 → 2s → 4s → 8s → 15s — max 5 attempts
const _profileRetryDelays = [0, 2000, 4000, 8000, 15000];

function scrapeAccountWhenReady() {
  clearTimeout(_profileScrapeTimer);
  _profileScrapeAttempt = 0;
  _tryProfileScrape();
}

function _tryProfileScrape() {
  const hasSkills   = extractSkills().length > 0;
  const hasOverview = !!extractOverview();
  const isLast      = _profileScrapeAttempt >= _profileRetryDelays.length - 1;

  if (hasSkills && hasOverview) {
    console.log("[UT] Profile ready (attempt", _profileScrapeAttempt + 1, ") — scraping");
    scrapeAccount();
    return;
  }

  if (isLast) {
    console.log("[UT] Profile max attempts reached — scraping with partial data");
    scrapeAccount();
    return;
  }

  _profileScrapeAttempt++;
  const delay = _profileRetryDelays[_profileScrapeAttempt];
  console.log("[UT] Profile not ready yet (attempt", _profileScrapeAttempt, ") — retrying in", delay, "ms");
  _profileScrapeTimer = setTimeout(_tryProfileScrape, delay);
}

// ── SCRAPER: Account / Profile (ONLY runs on /freelancers/* pages) ──
function scrapeAccount() {
  console.log("[UT] Scraping profile page...");

  const info = { capturedAt: new Date().toISOString() };
  const bodyText = document.body.innerText;

  // ── userId from URL: /freelancers/~01f1419b6ce5c07b08 ──
  const profileMatch = window.location.href.match(/\/freelancers\/~(\w+)/);
  if (profileMatch) info.userId = profileMatch[1];
  if (!info.userId) info.userId = extractUserId();

  // ── Name: first h1 or h2 that looks like a person's name ──
  const headings = document.querySelectorAll("h1, h2");
  for (const h of headings) {
    const text = h.textContent.trim();
    if (text.length >= 2 && text.length <= 40 && /^[A-Z][a-zA-Z.\s'-]+$/.test(text)) {
      info.name = text;
      break;
    }
  }

  // ── Professional title (heading-like element with "|" / "," / role keyword) ──
  info.title = extractTitle(info.name);

  // ── Photo URL ──
  // Use screen-size-independent signals only. The profile portrait always
  // lives at a /profile-portraits/ URL and uses the stable `air3-avatar`
  // class; prefer it scoped to the schema.org Person header so we don't
  // grab a "similar freelancer" portrait. (Do NOT key off layout classes
  // like air3-avatar-88 — the size suffix changes per breakpoint.)
  const personScope = document.querySelector('[itemtype*="schema.org/Person"]');
  const photoEl =
    (personScope && personScope.querySelector('img[src*="/profile-portraits/"]')) ||
    document.querySelector('img.air3-avatar[src*="/profile-portraits/"]') ||
    document.querySelector('img[src*="/profile-portraits/"]');
  if (photoEl) {
    info.photoUrl = photoEl.currentSrc || photoEl.src || null;
  }

  // Fallback: legacy heuristic (largest profile-ish image) only if the
  // stable portrait selector found nothing.
  if (!info.photoUrl) {
    const photoCandidates = Array.from(document.querySelectorAll("img"))
      .map((img) => ({
        img,
        src: img.currentSrc || img.src || "",
        area: (img.naturalWidth || img.width || 0) * (img.naturalHeight || img.height || 0),
      }))
      .filter((c) => c.src && /upwork|profile|avatar|photo/i.test(c.src) && !/icon|sprite|logo/i.test(c.src));
    if (photoCandidates.length > 0) {
      photoCandidates.sort((a, b) => b.area - a.area);
      info.photoUrl = photoCandidates[0].src;
    }
  }

  // ── Numeric stats (top metrics block) ──
  const connectsMatch = bodyText.match(/connects\s*:?\s*([\d,]+)/i);
  if (connectsMatch) info.connectsBalance = parseInt(connectsMatch[1].replace(/,/g, ""));

  const jssMatch =
    bodyText.match(/job\s*success\s*(?:score)?\s*:?\s*(\d+)\s*%?/i) ||
    bodyText.match(/(\d+)\s*%?\s*job\s*success/i);
  if (jssMatch) {
    const n = parseInt(jssMatch[1]);
    if (n > 0 && n <= 100) info.jss = n;
  }

  const rateMatch = bodyText.match(/\$([\d,.]+)\s*\/\s*hr/i);
  if (rateMatch) info.hourlyRate = "$" + rateMatch[1] + "/hr";

  const earningsMatch = bodyText.match(/\$([\d,.]+[KkMm+]*)\s*\n?\s*total\s*earnings/i);
  if (earningsMatch) info.totalEarnings = earningsMatch[1];

  const jobsMatch = bodyText.match(/(\d[\d,]*)\s*\n?\s*total\s*jobs/i);
  if (jobsMatch) info.totalJobs = parseInt(jobsMatch[1].replace(/,/g, ""));

  const hoursMatch = bodyText.match(/([\d,]+)\s*\n?\s*total\s*hours/i);
  if (hoursMatch) info.totalHours = parseInt(hoursMatch[1].replace(/,/g, ""));

  // ── Location ──
  const locMatch = bodyText.match(/([\w\s]+,\s*[\w\s]+)\s*[-–]\s*\d+:\d+\s*(?:am|pm)\s*local\s*time/i);
  if (locMatch) {
    info.location = locMatch[1].trim();
  } else {
    const locOnly = bodyText.match(/([A-Z][\w\s]+,\s*[A-Z][\w\s]+)/);
    if (locOnly && locOnly[1].length < 60) info.location = locOnly[1].trim();
  }

  // ── Overview / bio ──
  const ov = extractOverview();
  if (ov) info.overview = trimText(ov, 4000);

  // ── Skills ──
  info.skills = extractSkills();

  console.log(
    "[UT] Profile scraped:",
    JSON.stringify({
      ...info,
      overview: info.overview ? `${info.overview.length} chars` : null,
    }).slice(0, 600),
  );

  if (info.userId || info.name || info.connectsBalance || info.jss) {
    sendToBackground("SCRAPED_ACCOUNT", info);
  } else {
    console.log("[UT] No account data found");
  }
}

// ── Profile scraper helpers ─────────────────────────────────────────────
function trimText(s, max) {
  if (!s) return null;
  const t = String(s).replace(/\s+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
  return t.length > max ? t.slice(0, max) : t;
}

function findSectionByHeading(needles) {
  const headings = Array.from(document.querySelectorAll("h1, h2, h3, h4, [role='heading']"));
  for (const h of headings) {
    const t = (h.textContent || "").trim().toLowerCase();
    if (!needles.some((n) => t === n || t.startsWith(n))) continue;
    // Walk up to a sensible container, then collect sibling text
    let section = h.closest("section, [class*='section'], [class*='card'], [class*='module']");
    if (!section) {
      section = h.parentElement;
      // Climb until we have enough content
      while (section && section.innerText.length < 80 && section.parentElement) {
        section = section.parentElement;
      }
    }
    if (section) {
      const txt = section.innerText.replace(new RegExp("^" + h.textContent + "\\s*", "i"), "").trim();
      if (txt.length > 0) return txt;
    }
  }
  return null;
}

function extractSkills() {
  const seen = new Set();
  const out = [];

  const addChips = (container) => {
    if (!container) return;
    const chips = Array.from(container.querySelectorAll(
      "li, [class*='token'], [class*='chip'], [class*='tag'], [class*='skill'], [class*='badge'], button, span"
    ));
    for (const el of chips) {
      // Only leaf nodes — skip containers that have nested elements with text
      if (el.children.length > 2) continue;
      const t = (el.textContent || "").trim();
      if (!t || t.length > 60 || t.length < 2) continue;
      if (/^(more|less|view all|edit|add|skills?|expertise|and|,)/i.test(t)) continue;
      if (/^\d+$/.test(t)) continue;
      if (seen.has(t.toLowerCase())) continue;
      seen.add(t.toLowerCase());
      out.push(t);
      if (out.length >= 100) break;
    }
  };

  // Strategy 1: find via section heading
  const sectionEl = findSectionContainer(["skills", "skills and expertise"]);
  if (sectionEl) addChips(sectionEl);
  if (out.length > 0) return out;

  // Strategy 2: find any heading whose text is exactly "skills" and harvest siblings
  const allEls = document.querySelectorAll("h1,h2,h3,h4,h5,p,div,span");
  for (const h of allEls) {
    const t = (h.textContent || "").trim().toLowerCase();
    if (t !== "skills" && t !== "skills and expertise") continue;
    const sibling = h.nextElementSibling;
    const parent  = h.parentElement;
    addChips(sibling);
    if (out.length === 0) addChips(parent);
    if (out.length > 0) break;
  }

  return out;
}

function findSectionContainer(needles) {
  const headings = Array.from(document.querySelectorAll("h1, h2, h3, h4, [role='heading']"));
  for (const h of headings) {
    const t = (h.textContent || "").trim().toLowerCase();
    if (!needles.some((n) => t === n || t.startsWith(n))) continue;
    let section = h.closest("section, [class*='section'], [class*='card'], [class*='module']");
    if (section) return section;
    return h.parentElement;
  }
  return null;
}

function extractTitle(name) {
  const candidates = Array.from(
    document.querySelectorAll(
      "h1, h2, h3, h4, [role='heading'], [class*='title'], [class*='headline']",
    ),
  );
  const seen = new Set();
  for (const h of candidates) {
    const t = (h.textContent || "")
      .replace(/[​-‏﻿]/g, "")
      .replace(/\s+/g, " ")
      .trim();
    if (!t || t.length < 15 || t.length > 250) continue;
    if (name && t === name) continue;
    if (seen.has(t)) continue;
    seen.add(t);
    const hasPipeOrComma = t.includes("|") || t.includes(",");
    const hasRoleWord =
      /\b(developer|designer|engineer|specialist|consultant|expert|manager|architect|strategist|analyst|writer|marketer|automation|full[- ]?stack|fullstack|frontend|backend)\b/i.test(
        t,
      );
    if (hasPipeOrComma || hasRoleWord) return t;
  }
  return null;
}

function extractOverview() {
  const isBlurb = (t) => /^a summary of your upwork history/i.test(t);

  // Strategy 1: walk up from a "more"/"less" toggle — the bio uses one.
  const buttons = Array.from(document.querySelectorAll("button, a"));
  for (const btn of buttons) {
    const t = (btn.textContent || "").trim();
    if (!/^(show\s+)?(more|less)$/i.test(t)) continue;
    let el = btn.parentElement;
    for (let i = 0; i < 6 && el; i++) {
      const text = (el.innerText || "").trim();
      if (text.length > 200 && text.length < 8000 && !isBlurb(text)) {
        return text.replace(/\b(show\s+)?(more|less)\s*$/i, "").trim();
      }
      el = el.parentElement;
    }
  }

  // Strategy 2: heading-based search (skip the Upwork-AI blurb).
  const headed = findSectionByHeading(["overview", "about me", "summary"]);
  if (headed && !isBlurb(headed)) return headed;

  // Strategy 3: longest non-blurb paragraph fallback.
  const paragraphs = Array.from(
    document.querySelectorAll("p, [class*='description'], [class*='overview']"),
  )
    .map((el) => (el.innerText || "").trim())
    .filter((t) => t.length > 200 && t.length < 5000)
    .filter((t) => !isBlurb(t));
  return paragraphs[0] || null;
}

// ── SCRAPER: Stats Page ──
function scrapeStats() {
  console.log("[UT] Scraping stats page...");

  const stats = { capturedAt: new Date().toISOString(), metrics: {} };
  const bodyText = document.body.innerText;

  // Detect which Upwork date-range filter is active on the Proposals card.
  // Dropdown options are kept in the DOM even when the dropdown is closed —
  // we must exclude those (they're hidden) and only match the visible trigger.
  // Also when walking up we must not cross into an ancestor that encompasses
  // both the Proposals card and the Profile Metrics card (which also has a
  // "Last N days" dropdown).
  (() => {
    const labels = Array.from(document.querySelectorAll("button, span, div, [role='button']"))
      .filter((el) => {
        if (!/^Last\s+(7|30|90)\s+days$/i.test((el.textContent || "").trim())) return false;
        const rect = el.getBoundingClientRect();
        return rect.width > 0 && rect.height > 0;
      });
    for (const label of labels) {
      let parent = label.parentElement;
      for (let i = 0; i < 10 && parent; i++) {
        const txt = parent.innerText || "";
        if (/profile\s+metrics/i.test(txt)) break;
        if (/\d+\s+proposals?\s+sent/i.test(txt)) {
          const m = label.textContent.trim().match(/^Last\s+(7|30|90)\s+days$/i);
          if (m) {
            stats.range = m[1] === "7" ? "7d" : m[1] === "30" ? "30d" : "90d";
            return;
          }
        }
        parent = parent.parentElement;
      }
    }
  })();

  const metricPatterns = {
    proposals_sent: [/(\d+)\s*proposals?\s*sent/i, /sent\s*:?\s*(\d+)/i],
    proposals_viewed: [/(\d+)\s*(?:proposals?\s*)?(?:were\s*)?viewed/i, /(\d+)\s*were\s*viewed/i, /viewed\s*:?\s*(\d+)/i],
    proposals_interviewed: [/(\d+)\s*interview(?:s|ed)?/i, /interview(?:ed|s)?\s*:?\s*(\d+)/i],
    proposals_hired: [/(\d+)\s*hire[ds]?/i, /hire[ds]?\s*:?\s*(\d+)/i],
  };

  for (const [key, patterns] of Object.entries(metricPatterns)) {
    for (const regex of patterns) {
      const match = bodyText.match(regex);
      if (match) {
        stats.metrics[key] = parseInt(match[1]);
        break;
      }
    }
  }

  const connectsMatch = bodyText.match(/connects\s*:?\s*([\d,]+)/i);
  if (connectsMatch) stats.connectsBalance = parseInt(connectsMatch[1].replace(/,/g, ""));

  const jssMatch = bodyText.match(/job\s*success\s*(?:score)?\s*:?\s*(\d+)/i);
  if (jssMatch) stats.jss = parseInt(jssMatch[1]);

  stats.rawText = bodyText.slice(0, 3000);

  if (Object.keys(stats.metrics).length > 0 || stats.jss || stats.connectsBalance) {
    sendToBackground("SCRAPED_STATS", stats);
  } else {
    sendToBackground("SCRAPED_STATS_RAW", { rawText: stats.rawText, capturedAt: stats.capturedAt });
  }
}

// ── Scroll entire page/panel to trigger lazy-loaded content ──
async function scrollToLoadAll() {
  const panel = document.querySelector('[class*="drawer"], [class*="panel"], [class*="slider"], [class*="detail"], [role="dialog"]');
  const scrollTarget = panel || document.documentElement;
  const isPage = scrollTarget === document.documentElement;

  // Save original scroll position so we can restore it (don't reset to 0 on page)
  const originalScrollTop = scrollTarget.scrollTop;

  const scrollHeight = scrollTarget.scrollHeight;
  const step = 500;
  for (let pos = 0; pos < scrollHeight; pos += step) {
    // Abort if a panel scrape is running but the panel has since closed
    if (panel && !document.contains(panel)) return;
    scrollTarget.scrollTop = pos;
    await new Promise((r) => setTimeout(r, 150));
  }

  // Restore original position — never reset the page to top unexpectedly
  scrollTarget.scrollTop = isPage ? originalScrollTop : 0;
  await new Promise((r) => setTimeout(r, 1000));
}

// ── Find the job detail container (full page OR side panel) ──
function findJobContainer() {
  // The slider panel — Upwork uses a modal/slider for job details from the feed
  // Try multiple selectors from most specific to least
  const selectors = [
    // Upwork's slider panel (URL contains navType=slider)
    '[class*="slider"] [class*="content"]',
    '[class*="slider"]',
    '[class*="air3-slider"]',
    // Modal / drawer patterns
    '[class*="drawer"]',
    '[class*="modal-content"]',
    '[role="dialog"]',
    // Job detail specific
    '[class*="job-details"]',
    '[class*="detail-panel"]',
  ];

  for (const sel of selectors) {
    const els = document.querySelectorAll(sel);
    for (const el of els) {
      // Must have substantial content and contain job-like text
      if (el.innerText.length > 200 && (
        el.innerText.includes("Send a proposal") ||
        el.innerText.includes("Apply now") ||
        el.innerText.includes("Open job in a new window") ||
        el.innerText.includes("Summary")
      )) {
        console.log("[UT] Found job container via:", sel);
        return el;
      }
    }
  }

  // Fallback: find the element containing "Open job in a new window" and go up
  const openJobLink = Array.from(document.querySelectorAll("a")).find(
    (a) => /open\s*job\s*in\s*a\s*new\s*window/i.test(a.textContent)
  );
  if (openJobLink) {
    // Walk up to find a large container
    let parent = openJobLink.parentElement;
    while (parent && parent !== document.body) {
      if (parent.innerText.length > 500 && parent.offsetWidth > 300) {
        console.log("[UT] Found job container via Open Job link parent");
        return parent;
      }
      parent = parent.parentElement;
    }
  }

  // Full job page — use main content area
  const main = document.querySelector('main, [role="main"]');
  if (main) return main;

  return document.body;
}

// ── Extract job URL from the container or page ──
function findJobUrl(container) {
  // From the "Open job in a new window" link
  const openLink = container.querySelector('a[href*="/jobs/~"]');
  if (openLink) return openLink.href.split("?")[0];

  // From page URL
  const urlMatch = window.location.href.match(/(https:\/\/www\.upwork\.com\/jobs\/~\w+)/);
  if (urlMatch) return urlMatch[1];

  // From any canonical/og link
  const canonical = document.querySelector('link[rel="canonical"]');
  if (canonical?.href?.includes("/jobs/")) return canonical.href;

  return window.location.href;
}

// ── Extract job data from the current DOM (shared by scrapeJob and criteria retry) ──
async function scrapeJobData() {
  await scrollToLoadAll();

  const container = findJobContainer();
  const text = container.innerText;
  const job = { capturedAt: new Date().toISOString() };

  // ── URL ──
  job.url = findJobUrl(container);
  console.log({container,text})

  // ── Title: find the actual job title, skip all non-title text ──
  const sectionHeadings = ["summary", "skills", "activity on this job", "about the client",
    "experience level", "project type", "questions", "proposals", "featured jobs"];
  const headings = container.querySelectorAll('h1, h2, h3, h4');
  for (const h of headings) {
    const t = h.textContent.trim();
    if (t.length < 5 || t.length > 200) continue;
    const lower = t.toLowerCase();
    // Skip bad titles (Open job, My Proposals, etc.)
    if (isBadTitle(t)) continue;
    // Skip section headings
    if (sectionHeadings.some((s) => lower === s)) continue;
    // Skip generic UI text
    if (/^(contract|featured|upgrade|boost|promoted)/i.test(lower)) continue;
    // This should be the actual job title
    job.title = t;
    break;
  }

  // ── Budget ──
  const budgetMatch = text.match(/\$([\d,.]+)\s*\n?\s*(?:Fixed-price|fixed.price)/i);
  if (budgetMatch) {
    job.budget = "$" + budgetMatch[1];
    job.jobType = "fixed";
  }
  if (!job.budget) {
    const hourlyMatch = text.match(/\$([\d,.]+)\s*[-–]\s*\$([\d,.]+)\s*(?:\/\s*hr|hourly)/i);
    if (hourlyMatch) {
      job.budget = `$${hourlyMatch[1]} - $${hourlyMatch[2]}/hr`;
      job.jobType = "hourly";
    }
  }
  // Standalone price
  if (!job.budget) {
    const priceMatch = text.match(/\$([\d,]+(?:\.\d+)?)\s*\n/);
    if (priceMatch) job.budget = "$" + priceMatch[1];
  }

  // ── Job type (if not already set) ──
  if (!job.jobType) {
    if (/fixed.price/i.test(text)) job.jobType = "fixed";
    else if (/hourly/i.test(text)) job.jobType = "hourly";
  }

  // ── Experience level ──
  const expMatch = text.match(/(entry[\s-]?level|intermediate|expert)\s*[\n\s]*experience\s*level/i) ||
    text.match(/experience\s*level\s*[\n\s]*(entry[\s-]?level|intermediate|expert)/i) ||
    text.match(/\b(entry[\s-]?level|intermediate|expert)\b/i);
  if (expMatch) job.experienceLevel = expMatch[1];

  // ── Connects required: "Send a proposal for: 14 Connects" ──
  const connectsMatch = text.match(/(?:send\s*a\s*proposal\s*for|submit.*?for)\s*:?\s*(\d+)\s*connects/i) ||
    text.match(/(\d+)\s*connects?\s*(?:required|to\s*submit|needed)/i);
  if (connectsMatch) job.connectsRequired = parseInt(connectsMatch[1]);

  // ── Available connects ──
  const availConnects = text.match(/available\s*connects?\s*:?\s*([\d,]+)/i);
  if (availConnects) job.availableConnects = parseInt(availConnects[1].replace(/,/g, ""));

  // ── Posted time ──
  const postedMatch = text.match(/posted\s+(.+?)(?:\n|$)/i);
  if (postedMatch) job.postedTime = postedMatch[1].trim();

  // ── Job location (Worldwide, US only, etc.) — this is WHERE the job is, not the client ──
  const jobLocMatch = text.match(/(?:posted.*?\n.*?)\b(worldwide|united states only|us only)\b/i);
  if (jobLocMatch) job.jobLocation = jobLocMatch[1].trim();

  // ── Summary / Description (get FULL text, not just 500 chars) ──
  // Look for "Summary" section
  const summaryMatch = text.match(/summary\s*\n([\s\S]*?)(?=\n\s*\$[\d]|\n\s*skills|\n\s*activity|\n\s*about the client|\n\s*contract-to-hire|$)/i);
  if (summaryMatch) {
    job.description = summaryMatch[1].trim().slice(0, 2000);
  }
  // Fallback: description element
  if (!job.description) {
    const descEl = container.querySelector('[data-test="description"], [class*="description"], [class*="job-description"]');
    if (descEl) job.description = descEl.textContent.trim().slice(0, 2000);
  }

  // ── Skills ──
  const skillEls = container.querySelectorAll('.air3-badge, [class*="skill-badge"], [data-test="skill"], .up-skill-badge, [class*="air3-token"]');
  if (skillEls.length > 0) {
    job.skills = Array.from(skillEls)
      .map((el) => el.textContent.trim())
      .filter((s) => s.length > 0 && s.length < 50)
      .slice(0, 30);
  }

  // ── Project type: "Project Type: Ongoing project" ──
  const projMatch = text.match(/project\s*type\s*:?\s*(.+?)(?:\n|$)/i);
  if (projMatch) job.projectType = projMatch[1].trim();

  // ── Contract-to-hire ──
  if (/contract.to.hire/i.test(text)) job.contractToHire = true;

  // ── Client info — parse the "About the client" block as a whole ──
  const aboutMatch = text.match(/about\s*the\s*client([\s\S]*?)(?=\n\s*job\s*link|\n\s*similar\s*jobs|\n\s*how\s*it\s*works|\n\s*activity\s*on\s*this\s*job|$)/i);
  if (aboutMatch) {
    const block = aboutMatch[1];
    const lines = block.split("\n").map((l) => l.trim()).filter(Boolean);

    // Payment & phone verified
    job.clientPaymentVerified = /payment\s*(?:method\s*)?verified/i.test(block);
    job.clientPhoneVerified = /phone\s*(?:number\s*)?verified/i.test(block);

    // Rating — standalone float like "5.0" (the big star rating)
    const ratingLine = lines.find((l) => /^\d+\.\d+$/.test(l));
    if (ratingLine) job.clientRating = parseFloat(ratingLine);

    // Review score — "5.00 of 4 reviews"
    const reviewMatch = block.match(/([\d.]+)\s*of\s*(\d+)\s*reviews?/i);
    if (reviewMatch) {
      job.clientReviewScore = reviewMatch[0].trim();
      job.clientReviews = parseInt(reviewMatch[2]);
      if (!job.clientRating) job.clientRating = parseFloat(reviewMatch[1]);
    }

    // Country & City — look for a short uppercase code (e.g. "FRA") or country name,
    // followed by a city + time line like "Paris  1:38 PM"
    const countryIdx = lines.findIndex((l) =>
      /^[A-Z]{2,4}$/.test(l) || // ISO-like codes: US, FRA, DEU, etc.
      /^(United States|United Kingdom|Canada|Australia|India|Pakistan|Germany|France|Thailand|Philippines|Singapore|Netherlands|Israel|Brazil|Japan|China|South Korea|Spain|Italy|Sweden|Norway|Denmark|Switzerland|Ireland|New Zealand|Mexico|Argentina|Colombia|Chile|Egypt|Nigeria|Kenya|South Africa|UAE|Saudi Arabia|Bangladesh|Sri Lanka|Vietnam|Indonesia|Malaysia|Turkey|Poland|Ukraine|Romania|Czech Republic|Hungary|Portugal|Greece|Belgium|Austria|Finland|Russia|Belarus|Georgia|Armenia|Azerbaijan|Jordan|Lebanon|Qatar|Bahrain|Kuwait|Oman)$/i.test(l)
    );
    if (countryIdx !== -1) {
      job.clientCountry = lines[countryIdx];
      // Next line is typically "City  TIME" — extract city before double-space or time pattern
      const nextLine = lines[countryIdx + 1];
      if (nextLine) {
        const cityMatch = nextLine.match(/^(.+?)\s{2,}/) || nextLine.match(/^(.+?)\s+\d{1,2}:\d{2}\s*(AM|PM|am|pm)/);
        if (cityMatch) job.clientCity = cityMatch[1].trim();
      }
    }

    // Total spent — "$1.4K total spent" or "$10K+ spent"
    const spentMatch = block.match(/\$([\d,.]+[KkMm]*\+?)\s*(?:total\s*)?spent/i);
    if (spentMatch) job.clientSpent = "$" + spentMatch[1];

    // Jobs posted — "4 jobs posted"
    const jobsPostedMatch = block.match(/(\d+)\s*jobs?\s*posted/i);
    if (jobsPostedMatch) job.clientJobsPosted = parseInt(jobsPostedMatch[1]);

    // Hire rate & open jobs — "100% hire rate, 2 open jobs"
    const hireRateMatch = block.match(/(\d+)%\s*hire\s*rate/i);
    if (hireRateMatch) job.clientHireRate = parseInt(hireRateMatch[1]);
    const openJobsMatch = block.match(/(\d+)\s*open\s*jobs?/i);
    if (openJobsMatch) job.clientOpenJobs = parseInt(openJobsMatch[1]);

    // Hires & active — "5 hires, 1 active"
    const hiresMatch = block.match(/(\d+)\s*hires?\s*,?\s*(\d+)\s*active/i);
    if (hiresMatch) {
      job.clientHires = parseInt(hiresMatch[1]);
      job.clientActiveHires = parseInt(hiresMatch[2]);
    }

    // Industry — e.g. "Tech & IT", "Sales & Marketing" — a line with "&" that isn't money
    const industryLine = lines.find((l) => /&/.test(l) && !/\$/.test(l) && l.length < 40 && !/hire|job|member|spent|verified/i.test(l));
    if (industryLine) job.clientIndustry = industryLine;

    // Company size — "Small company (2-9 people)" or "Mid-sized company (10-99 people)"
    const companySizeMatch = block.match(/((?:small|mid[- ]?sized|large)\s*company\s*\([^)]+\))/i);
    if (companySizeMatch) job.clientCompanySize = companySizeMatch[1].trim();

    // Member since — "Member since Aug 23, 2025"
    const memberMatch = block.match(/member\s*since\s*(.+?)(?:\n|$)/i);
    if (memberMatch) job.clientMemberSince = memberMatch[1].trim();
  }

  // ── Activity on this job — Proposals count + Interviewing count ──
  const activityMatch = text.match(/activity\s*on\s*this\s*job([\s\S]*?)(?=\n\s*job\s*link|\n\s*about\s*the\s*client|\n\s*similar\s*jobs|$)/i);
  if (activityMatch) {
    const actBlock = activityMatch[1];
    const interviewM = actBlock.match(/interviewing\s*:?\s*(\d+)/i);
    if (interviewM) job.interviewing = parseInt(interviewM[1]);
    const proposalM = actBlock.match(/proposals?\s*:?\s*([^\n]{1,30})/i);
    if (proposalM) job.jobProposals = parseProposalRange(proposalM[1].trim());
    const hiresM = actBlock.match(/^hires\s*:?\s*(\d+)/im);
    if (hiresM) job.jobHires = parseInt(hiresM[1]);
    const viewedM = actBlock.match(/last\s*viewed\s*by\s*client\s*:?\s*([^\n]{1,40})/i);
    if (viewedM) job.lastViewedHours = parseLastViewed(viewedM[1].trim());
  }

  console.log("[UT] Job scraped:", JSON.stringify(job).slice(0, 500));
  return job;
}

// ── SCRAPER: Job Post (full page OR side panel) ──
async function scrapeJob() {
  console.log("[UT] Scraping job post...");
  const job = await scrapeJobData();
  if (job.title) {
    sendToBackground("SCRAPED_JOB", job);
    evaluateAndShowCriteria(job).catch(() => {});
  } else {
    console.log("[UT] No job title found");
  }
}

// ── SCRAPER: Proposals List (with pagination) ──
async function scrapeProposals() {
  console.log("[UT] Scraping proposals page...");

  const allProposals = [];
  let pageNum = 1;
  const maxPages = 20;

  while (pageNum <= maxPages) {
    console.log("[UT] Scraping proposals page", pageNum);
    await scrollToLoadAll();

    const bodyText = document.body.innerText;
    const proposals = [];
    const usedLinks = new Set();

    const lines = bodyText.split("\n").map((l) => l.trim()).filter(Boolean);
    let currentSection = "Unknown";

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];

      const sectionMatch = line.match(/^(Offers?|Invites?\s*from\s*clients?|Active\s*proposals?|Submitted\s*proposals?)\s*\(\d+\)/i);
      if (sectionMatch) {
        const raw = sectionMatch[1].trim().toLowerCase().replace(/\s+/g, " ");
        const canonicalMap = {
          "offers": "Offers",
          "offer": "Offers",
          "invites from clients": "Invites from clients",
          "invite from client": "Invites from clients",
          "invites from client": "Invites from clients",
          "active proposals": "Active proposals",
          "active proposal": "Active proposals",
          "submitted proposals": "Submitted proposals",
          "submitted proposal": "Submitted proposals",
        };
        currentSection = canonicalMap[raw] || sectionMatch[1].trim();
        continue;
      }

      const dateMatch = line.match(/^(?:Initiated|Received)\s+(.+)/i);
      if (dateMatch) {
        const proposal = {
          section: currentSection,
          submittedAt: dateMatch[1].trim(),
          boosted: false,
        };

        for (let j = i + 1; j < Math.min(i + 6, lines.length); j++) {
          const next = lines[j];

          if (/^Boosted$/i.test(next)) {
            proposal.boosted = true;
            proposal.boostStatus = "Boosted";
          } else if (/^Boost\s*outbid$/i.test(next)) {
            proposal.boosted = true;
            proposal.boostStatus = "Boost outbid";
          }

          if (/^[A-Za-z][A-Za-z ]*\sProfile$/.test(next) && next.length < 40) {
            proposal.profileUsed = next;
          }

          if (/^\d+\s*(second?|seconds?|minute?|minutes?|hour?|hours?|day?|days?|week?|weeks?|month?|months?|quarter?|quarters?)\s*ago$|^yesterday$|^last\s*(week|month|quarter)$/i.test(next)) {
            proposal.relativeTime = next;
          }

          if (/viewed\s*by\s*client/i.test(next)) {
            proposal.viewedByClient = true;
          }

          if (/^(job is closed|declined by you|declined by client|hired|offered|interviewed)$/i.test(next)) {
            proposal.status = next;
          }
        }

        const allLinks = document.querySelectorAll('a[href*="/jobs/"], a[href*="/proposals/"]');
        for (const link of allLinks) {
          if (usedLinks.has(link)) continue;
          const linkText = link.textContent.trim();
          if (linkText.length < 5 || isBadTitle(linkText)) continue;
          const row = link.closest("tr, [class*='row'], [class*='card'], [class*='tile'], section, li, div[class]");
          if (row && (row.innerText.includes(dateMatch[0]) || row.innerText.includes(dateMatch[1]))) {
            proposal.title = linkText;
            // Extract proper Upwork job URL from whatever link format
            const href = link.href;
            const jobIdMatch = href.match(/~(\w{15,})/);
            if (jobIdMatch) {
              proposal.url = "https://www.upwork.com/jobs/~" + jobIdMatch[1];
            } else {
              proposal.url = href.split("?")[0];
            }
            usedLinks.add(link);
            break;
          }
        }

        if (!proposal.title) {
          for (let j = i + 1; j < Math.min(i + 6, lines.length); j++) {
            const next = lines[j];
            if (next.length > 10 && !isBadTitle(next) &&
              !/^Initiated|^Received|^Boosted|^Boost\s|profile$/i.test(next) &&
              !/^\d+\s*(second?|seconds?|minute?|minutes?|hour?|hours?|day?|days?|week?|weeks?|month?|months?|quarter?|quarters?)\s*ago/i.test(next) &&
              !/^yesterday$|^last\s/i.test(next)) {
              proposal.title = next;
              break;
            }
          }
        }

        if (proposal.title) {
          proposals.push(proposal);
        }
      }
    }

    // Fallback for this page: try DOM links
    if (proposals.length === 0) {
      // Only accept links pointing at a real Upwork job posting (~01…);
      // this keeps nav/footer links like "Search for jobs" out of the DB.
      const links = document.querySelectorAll('a[href*="/jobs/~"], a[href*="/proposals/job/~"]');
      const seen = new Set();
      for (const link of links) {
        const text = link.textContent.trim();
        const href = link.href.split("?")[0];
        const jobIdMatch = href.match(/~(\w{15,})/);
        if (jobIdMatch && text.length > 5 && !seen.has(href) && !isBadTitle(text)) {
          seen.add(href);
          const canonicalUrl = "https://www.upwork.com/jobs/~" + jobIdMatch[1];
          proposals.push({ title: text, url: canonicalUrl, section: "Unknown", boosted: false });
        }
      }
    }

    allProposals.push(...proposals);
    console.log("[UT] Page", pageNum, "found", proposals.length, "proposals. Total:", allProposals.length);

    // Scope pagination search to an actual pagination container so we don't
    // accidentally click chevrons/arrows on proposal rows (which navigate to
    // a random proposal — especially on the Archive tab, which usually has
    // no multi-page pagination at all).
    const searchRoot = document.querySelector(
      'nav[aria-label*="pagination" i], [role="navigation"][aria-label*="pagination" i], [class*="pagination" i], [data-test*="pagination" i]'
    );

    const isRowLink = (el) => {
      if (el.tagName !== "A") return false;
      const href = el.getAttribute("href") || "";
      return /\/(jobs|proposals)\//.test(href);
    };

    let nextBtn = null;
    if (searchRoot) {
      nextBtn = Array.from(searchRoot.querySelectorAll('button, a, [role="button"]')).find((el) => {
        if (isRowLink(el)) return false;
        const text = el.textContent.trim();
        const ariaLabel = (el.getAttribute("aria-label") || "").toLowerCase();
        if (ariaLabel.includes("next")) return true;
        if (text === "›" || text === ">" || text === "→" || text === "»" || text === "Next") return true;
        if (text === String(pageNum + 1)) return true;
        return false;
      });

      // Fallback: SVG arrow button inside pagination container only
      if (!nextBtn) {
        const allBtns = searchRoot.querySelectorAll('button, a, [role="button"]');
        for (const btn of allBtns) {
          if (isRowLink(btn)) continue;
          const svg = btn.querySelector("svg");
          if (svg && btn.getBoundingClientRect().x > 0) {
            const prevSibling = btn.previousElementSibling;
            if (prevSibling && /^\d+$/.test(prevSibling.textContent.trim())) {
              const lastPageNum = parseInt(prevSibling.textContent.trim());
              if (lastPageNum > pageNum) {
                nextBtn = btn;
                break;
              }
            }
          }
        }
      }
    }

    if (nextBtn && !nextBtn.disabled && !nextBtn.getAttribute("aria-disabled")) {
      nextBtn.click();
      pageNum++;
      // Wait for new page content to load
      await new Promise((r) => setTimeout(r, 2500));
    } else {
      break;
    }
  }

  console.log("[UT] Scraped", allProposals.length, "total proposals across", pageNum, "pages");
  if (allProposals.length > 0) {
    sendToBackground("SCRAPED_PROPOSALS", { proposals: allProposals, capturedAt: new Date().toISOString() });
  }
}

// ── SCRAPER: Proposal Detail Page (/nx/proposals/NUMBERS) ──
async function scrapeProposalDetail() {
  console.log("[UT] Scraping proposal detail page...");
  await scrollToLoadAll();

  // Click all "more" links to expand truncated descriptions
  const moreLinks = document.querySelectorAll("a, button, span");
  for (const el of moreLinks) {
    const t = el.textContent.trim().toLowerCase();
    if (t === "more" || t === "... more" || t === "…more") {
      try { el.click(); } catch (_) {}
    }
  }
  // Wait for expanded content to render
  await new Promise((r) => setTimeout(r, 1500));

  const text = document.body.innerText;
  const proposal = { capturedAt: new Date().toISOString() };

  // Get the proposal URL as identifier
  proposal.detailUrl = window.location.href;
  const isInterview = /\/proposals\/interview\/uid\//.test(proposal.detailUrl);

  if (isInterview) {
    proposal.section = "Invites from clients";
    const heading = (document.querySelector("h1, h2")?.textContent || "").trim().toLowerCase();
    if (/declined\s+invitation/.test(heading)) proposal.status = "Declined by You";
    else if (/accepted\s+invitation/.test(heading)) proposal.status = "Accepted";
  }

  // ── Job URL from links ──
  const jobLinks = document.querySelectorAll('a[href*="/jobs/~"]');

  // First: get the canonical job URL from "View job posting" link
  for (const link of jobLinks) {
    if (/view\s*job/i.test(link.textContent.trim())) {
      proposal.url = link.href.split("?")[0];
      break;
    }
  }

  // Second: find a good title from non-"View job" links
  for (const link of jobLinks) {
    const linkText = link.textContent.trim();
    if (isBadTitle(linkText) || /^view\s*job/i.test(linkText)) continue;
    if (linkText.length > 5) {
      proposal.title = linkText;
      if (!proposal.url) proposal.url = link.href.split("?")[0];
      break;
    }
  }

  // Fallback: look for title under "Job details" section
  if (!proposal.title) {
    const jobDetailsMatch = text.match(/job\s*details\s*\n\s*(.+?)(?:\n|$)/i);
    if (jobDetailsMatch) {
      const t = jobDetailsMatch[1].trim();
      if (t.length > 3 && !isBadTitle(t)) {
        proposal.title = t;
      }
    }
  }

  // Fallback: find title from page heading, skip known non-title headings
  if (!proposal.title) {
    const skipHeadings = /^cover\s*letter$|^messages$|^client$|^about\s*the\s*client$|^view\s*job|^proposal\s*details$|^job\s*details$|^insights$|^average|^top\s*profile|^upgrade|^your\s*proposed|^boosted|^skills/i;
    const headings = document.querySelectorAll("h1, h2, h3");
    for (const h of headings) {
      const t = h.textContent.trim();
      if (t.length > 3 && !isBadTitle(t) && !skipHeadings.test(t)) {
        proposal.title = t;
        break;
      }
    }
  }

  // ── Job Category — try badge elements first (grey tag under title) ──
  const catBadges = document.querySelectorAll('.air3-badge, [class*="badge"], [class*="tag"], [class*="token"], [class*="chip"]');
  for (const badge of catBadges) {
    const t = badge.textContent.trim();
    if (t.length > 3 && t.length < 60 && /&|Development|Design|Writing|Marketing|Data|AI|Automation|Scripting|Web|Mobile|Software|Engineering|Sales|Admin|Legal|Accounting|Translation|IT|Consulting|Labeling|Annotation/i.test(t) && !/^(Boosted|Boost outbid)$/i.test(t)) {
      const parent = badge.closest("section, [class*='section'], [class*='card'], [class*='detail']") || badge.parentElement?.parentElement;
      if (parent && /job\s*details|Posted/i.test(parent.innerText.slice(0, 200))) {
        proposal.jobCategory = t;
        break;
      }
    }
  }
  // Fallback: text regex
  if (!proposal.jobCategory) {
    const categoryMatch = text.match(/^([\w\s&]+?)\s{2,}Posted\s/m) ||
      text.match(/job\s*details[\s\S]*?\n(.+?)\s{2,}Posted\s/i) ||
      text.match(/job\s*details\s*\n[^\n]+\n\s*(.+?)\s+Posted\s/i);
    if (categoryMatch) {
      const cat = categoryMatch[1].trim();
      if (cat.length > 2 && cat.length < 60 && !isBadTitle(cat)) {
        proposal.jobCategory = cat;
      }
    }
  }

  // ── Submission timestamp — "Initiated Apr 27, 2026" or "Initiated Apr 27, 2026 at 3:45 PM" ──
  const initiatedMatch = text.match(
    /(?:Initiated|Received|Submitted)\s+((?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2},?\s*\d{4}(?:\s+(?:at\s+)?\d{1,2}:\d{2}\s*(?:AM|PM))?)/i
  );
  if (initiatedMatch) proposal.submittedAt = initiatedMatch[1].trim();

  // ── Job Posted Date — "Posted Apr 16, 2026" ──
  const postedMatch = text.match(/Posted\s+((?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2},?\s*\d{4})/i);
  if (postedMatch) proposal.jobPostedDate = postedMatch[1].trim();

  // ── Job Budget — "$5.00 - $10.00 / Hourly range" or "$500.00 / Fixed-price" ──
  const hourlyRangeMatch = text.match(/\$([\d,.]+)\s*[-–]\s*\$([\d,.]+)\s*\/?\s*Hourly\s*range/i);
  if (hourlyRangeMatch) {
    proposal.jobBudget = `$${hourlyRangeMatch[1]} - $${hourlyRangeMatch[2]}/hr`;
  }
  if (!proposal.jobBudget) {
    const fixedMatch = text.match(/\$([\d,.]+)\s*\/?\s*Fixed[- ]?price/i);
    if (fixedMatch) proposal.jobBudget = "$" + fixedMatch[1];
  }
  if (!proposal.jobBudget) {
    const budgetMatch = text.match(/\$([\d,.]+)\s*\n?\s*(?:Fixed-price|fixed.price)/i);
    if (budgetMatch) proposal.jobBudget = "$" + budgetMatch[1];
  }

  // ── Experience Level — "Intermediate / Experience level" ──
  const expMatch = text.match(/(Entry[\s-]?level|Intermediate|Expert)\s*\/?\s*Experience\s*level/i) ||
    text.match(/(entry[\s-]?level|intermediate|expert)\b/i);
  if (expMatch) proposal.jobExperienceLevel = expMatch[1].trim();

  // ── Hours per week — "Less than 30 hrs/week / Hourly" ──
  const hoursMatch = text.match(/((?:Less than|More than)?\s*\d+\s*hrs?\s*\/\s*week)\s*\/?\s*Hourly/i) ||
    text.match(/((?:Less than|More than)?\s*\d+\s*hrs?\s*\/\s*week)/i);
  if (hoursMatch) proposal.jobHoursPerWeek = hoursMatch[1].trim();

  // ── Duration — "1 to 3 months / Project length" ──
  const durationMatch = text.match(/((?:\d+\s*to\s*\d+\s*(?:months?|weeks?|days?)|Less than (?:a )?(?:month|week)|More than \d+ months?))\s*\/?\s*Project\s*length/i) ||
    text.match(/((?:\d+\s*to\s*\d+\s*(?:months?|weeks?|days?)))/i);
  if (durationMatch) proposal.jobDuration = durationMatch[1].trim();

  // ── Job Description — text from Job details section ──
  const descMatch = text.match(/job\s*details\s*\n([\s\S]*?)(?=\nSkills and expertise|\nView job posting|\nBoosted proposal|\nCover letter|\nYour proposed)/i);
  if (descMatch) {
    // Clean out the title line, category line, and metadata lines
    let desc = descMatch[1].trim();
    // Remove lines that are clearly metadata (budget, experience, etc.)
    const descLines = desc.split("\n").filter((l) => {
      const trimmed = l.trim();
      if (!trimmed) return false;
      if (/^\$[\d,.]+\s*[-–]/.test(trimmed)) return false;
      if (/^\$[\d,.]+\s*$/.test(trimmed)) return false;
      if (/Experience\s*level$/i.test(trimmed)) return false;
      if (/Hourly\s*range$/i.test(trimmed)) return false;
      if (/Fixed[- ]?price$/i.test(trimmed)) return false;
      if (/hrs?\s*\/\s*week/i.test(trimmed)) return false;
      if (/Project\s*length$/i.test(trimmed)) return false;
      if (/Posted\s+(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)/i.test(trimmed)) return false;
      if (/^\/?(Entry|Intermediate|Expert)/i.test(trimmed)) return false;
      if (/^(Intermediate|Expert|Entry[\s-]?level)$/i.test(trimmed)) return false;
      if (/^(Hourly|Fixed-price|Less than|More than)$/i.test(trimmed)) return false;
      if (/^\d+\s*to\s*\d+\s*months?$/i.test(trimmed)) return false;
      // Filter category tags — short lines matching known Upwork categories
      if (/^(Scripting|Web Development|Software|Mobile|Data|Design|Writing|Admin|Sales|Marketing|IT|Engineering|Accounting|Legal|Customer|Translation|Ecommerce|Bot|AI|Machine|Blockchain|Cloud|DevOps|QA|Testing|SEO|Social|Video|Audio|Photo|Animation|Game|AR|VR)\s*[&\w\s]*$/i.test(trimmed) && trimmed.length < 40) return false;
      return true;
    });
    // Skip the first line if it looks like the title
    if (descLines.length > 1 && proposal.title && descLines[0].includes(proposal.title)) {
      descLines.shift();
    }
    // Also skip category-like first line
    if (descLines.length > 1 && proposal.jobCategory && descLines[0].includes(proposal.jobCategory)) {
      descLines.shift();
    }
    // Skip any remaining metadata lines at the start
    while (descLines.length > 0) {
      const first = descLines[0].trim();
      if (/^(Scripting|Web|Software|Mobile|Data|Design|Writing|Admin|Sales|IT|Bot|AI|Ecommerce)\b/i.test(first) && first.length < 40) {
        descLines.shift();
      } else if (/^Posted\s/i.test(first)) {
        descLines.shift();
      } else if (/^View\s*job\s*posting$/i.test(first)) {
        descLines.shift();
      } else {
        break;
      }
    }
    desc = descLines.join("\n").trim();
    // Remove "more", "less", "More/Less about" artifacts from expanded text
    desc = desc.replace(/\s*\bless\b\s*$/gim, "");
    desc = desc.replace(/\s*More\/Less about\s*/gi, "");
    desc = desc.replace(/\s*\bmore\b\s*$/gim, "");
    // Remove "Skills and expertise" heading and "View job posting" if leaked in
    desc = desc.replace(/^\s*Skills and expertise\s*$/gim, "");
    desc = desc.replace(/^\s*View job posting\s*$/gim, "");
    // Remove category tag if it leaked in
    if (proposal.jobCategory) {
      desc = desc.replace(new RegExp("^\\s*" + proposal.jobCategory.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "\\s*$", "gim"), "");
    }
    // Store raw description temporarily — will clean skill names after skills are extracted
    desc = desc.replace(/\n{3,}/g, "\n\n").trim();
    if (desc.length > 10) {
      proposal.jobDescription = desc;
    }
  }

  // ── Skills — prefer badge elements (clean separate values) over text parsing ──
  const skillEls = document.querySelectorAll('.air3-badge, [class*="skill-badge"], [data-test="skill"], .up-skill-badge, [class*="air3-token"], [class*="badge"]');
  const badgeSkills = Array.from(skillEls)
    .map((el) => el.textContent.trim())
    .filter((s) => s.length > 1 && s.length < 50 && !/^(Boosted|Boost outbid|General|Specialized|New)$/i.test(s));
  if (badgeSkills.length > 0) {
    proposal.jobSkills = [...new Set(badgeSkills)].slice(0, 30);
  } else {
    // Fallback: text parsing — but split concatenated skills by capital letters
    const skillsMatch = text.match(/skills\s*and\s*expertise\s*\n([\s\S]*?)(?=\nBoosted proposal|\nCover letter|\nYour proposed|\nAbout the client)/i);
    if (skillsMatch) {
      const raw = skillsMatch[1].trim();
      let skills = raw.split("\n").map((l) => l.trim()).filter((l) => l.length > 0 && l.length < 50);
      // If only one long line, split by capital letter boundaries
      if (skills.length === 1 && skills[0].length > 30) {
        skills = skills[0].split(/(?<=[a-z])(?=[A-Z])/).map((s) => s.trim()).filter(Boolean);
      }
      if (skills.length > 0) proposal.jobSkills = skills;
    }
  }

  // ── Clean skill names from description (now that skills are extracted) ──
  if (proposal.jobDescription && proposal.jobSkills && proposal.jobSkills.length > 0) {
    let cleanDesc = proposal.jobDescription;
    for (const skill of proposal.jobSkills) {
      cleanDesc = cleanDesc.replace(new RegExp("^\\s*" + skill.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "\\s*$", "gim"), "");
    }
    cleanDesc = cleanDesc.replace(/\n{3,}/g, "\n\n").trim();
    proposal.jobDescription = cleanDesc;
  }

  // ── Boosted proposal — "Your bid is set to 9 Connects." ──
  const bidMatch = text.match(/(?:bid|boost).*?(\d+)\s*Connects/i);
  if (bidMatch) proposal.bidConnects = parseInt(bidMatch[1]);

  // ── Cover letter (proposals) / Personal note from client (interviews) ──
  if (isInterview) {
    const noteMatch = text.match(/personal\s*note\s*from\s*client\s*\n([\s\S]*?)(?=\n\s*(?:About the client|Messages|View job|Decline|Accept|$))/i);
    if (noteMatch) proposal.clientNote = noteMatch[1].trim();
    // Fallback: section-element scan
    if (!proposal.clientNote) {
      const sections = document.querySelectorAll("section, [class*='section'], [class*='card']");
      for (const sec of sections) {
        if (sec.innerText.toLowerCase().startsWith("personal note from client")) {
          const fullText = sec.innerText.replace(/^personal\s*note\s*from\s*client\s*/i, "").trim();
          if (fullText.length) {
            proposal.clientNote = fullText;
            break;
          }
        }
      }
    }
  } else {
    const coverMatch = text.match(/cover\s*letter\s*\n([\s\S]*?)(?=\n\s*(?:Profile highlights|Messages|Client|About the client|Edit proposal|Withdraw proposal|Your proposed|Bid|Terms|Boosted proposal|How do you|Upgrade to))/i);
    if (coverMatch) {
      proposal.coverLetter = coverMatch[1].trim();
    }
    if (!proposal.coverLetter) {
      const sections = document.querySelectorAll("section, [class*='section'], [class*='card']");
      for (const sec of sections) {
        if (sec.innerText.toLowerCase().startsWith("cover letter")) {
          const fullText = sec.innerText.replace(/^cover\s*letter\s*/i, "").trim();
          if (fullText.length) {
            proposal.coverLetter = fullText;
            break;
          }
        }
      }
    }
  }

  // ── Your proposed terms ──
  const termsMatch = text.match(/your\s*proposed\s*terms\s*\n([\s\S]*?)(?=\nAbout the client|\nMessages|\nEdit proposal|\nWithdraw|$)/i);
  if (termsMatch) {
    const termsBlock = termsMatch[1];

    // Profile used — "Profile: General Profile"
    const profileMatch = termsBlock.match(/Profile\s*:?\s*(.+?)(?:\n|$)/i);
    if (profileMatch) proposal.profileUsed = profileMatch[1].trim();

    // Hourly rate — "Hourly rate: $10.00/hr"
    const rateMatch = termsBlock.match(/Hourly\s*rate\s*:?\s*\$([\d,.]+)\s*\/?\s*hr/i);
    if (rateMatch) proposal.proposedRate = "$" + rateMatch[1] + "/hr";

    // You'll receive — "You'll receive: $9.00/hr"
    const receiveMatch = termsBlock.match(/(?:You.ll|You will)\s*receive\s*:?\s*\$([\d,.]+)\s*\/?\s*hr/i);
    if (receiveMatch) proposal.receivedRate = "$" + receiveMatch[1] + "/hr";

    // Rate increase — "Rate increase: None" or "Rate increase: $5.00/hr after 3 months"
    const increaseMatch = termsBlock.match(/Rate\s*increase\s*:?\s*(.+?)(?:\n|$)/i);
    if (increaseMatch) proposal.rateIncrease = increaseMatch[1].trim();
  }

  // ── Viewed by client ──
  proposal.viewedByClient = /proposal\s*was\s*viewed|viewed\s*by\s*client/i.test(text);

  // ── Client name — from "Client" section (not "About the client") ──
  const clientNameMatch = text.match(/(?:^|\n)\s*Client\s*\n\s*(.+?)(?:\n|$)/);
  if (clientNameMatch) {
    const name = clientNameMatch[1].trim();
    if (name.length > 1 && name.length < 100 && !/payment|phone|verified|about\s*the/i.test(name)) {
      proposal.clientName = name;
    }
  }

  // ── About the client — full block parse (same approach as job scraper) ──
  const aboutMatch = text.match(/about\s*the\s*client([\s\S]*?)(?=\n\s*job\s*link|\n\s*similar\s*jobs|\n\s*how\s*it\s*works|\n\s*activity\s*on\s*this\s*job|\n\s*edit\s*proposal|\n\s*withdraw|$)/i);
  if (aboutMatch) {
    const block = aboutMatch[1];
    const lines = block.split("\n").map((l) => l.trim()).filter(Boolean);

    // Payment verified
    proposal.clientPaymentVerified = /payment\s*(?:method\s*)?verified/i.test(block);

    // Rating — standalone float like "4.3"
    const ratingLine = lines.find((l) => /^\d+\.\d+$/.test(l));
    if (ratingLine) proposal.clientRating = parseFloat(ratingLine);

    // Review score — "4.27 of 19 reviews"
    const reviewMatch = block.match(/([\d.]+)\s*of\s*(\d+)\s*reviews?/i);
    if (reviewMatch) {
      proposal.clientReviewScore = reviewMatch[0].trim();
      proposal.clientReviews = parseInt(reviewMatch[2]);
      if (!proposal.clientRating) proposal.clientRating = parseFloat(reviewMatch[1]);
    }

    // Country & City
    const countryIdx = lines.findIndex((l) =>
      /^[A-Z]{2,4}$/.test(l) ||
      /^(United States|United Kingdom|Canada|Australia|India|Pakistan|Germany|France|Thailand|Philippines|Singapore|Netherlands|Israel|Brazil|Japan|China|South Korea|Spain|Italy|Sweden|Norway|Denmark|Switzerland|Ireland|New Zealand|Mexico|Argentina|Colombia|Chile|Egypt|Nigeria|Kenya|South Africa|UAE|Saudi Arabia|Bangladesh|Sri Lanka|Vietnam|Indonesia|Malaysia|Turkey|Poland|Ukraine|Romania|Czech Republic|Hungary|Portugal|Greece|Belgium|Austria|Finland|Russia|Belarus|Georgia|Armenia|Azerbaijan|Jordan|Lebanon|Qatar|Bahrain|Kuwait|Oman)$/i.test(l)
    );
    if (countryIdx !== -1) {
      proposal.clientCountry = lines[countryIdx];
      // Next line is typically "City  TIME"
      const nextLine = lines[countryIdx + 1];
      if (nextLine) {
        const cityMatch = nextLine.match(/^(.+?)\s{2,}/) || nextLine.match(/^(.+?)\s+\d{1,2}:\d{2}\s*(AM|PM|am|pm)/);
        if (cityMatch) proposal.clientCity = cityMatch[1].trim();
      }
    }

    // Jobs posted — "20 jobs posted"
    const jobsPostedMatch = block.match(/(\d+)\s*jobs?\s*posted/i);
    if (jobsPostedMatch) proposal.clientJobsPosted = parseInt(jobsPostedMatch[1]);

    // Hire rate & open jobs — "100% hire rate, 3 open jobs"
    const hireRateMatch = block.match(/(\d+)%\s*hire\s*rate/i);
    if (hireRateMatch) proposal.clientHireRate = parseInt(hireRateMatch[1]);
    const openJobsMatch = block.match(/(\d+)\s*open\s*jobs?/i);
    if (openJobsMatch) proposal.clientOpenJobs = parseInt(openJobsMatch[1]);

    // Total spent — "$11K total spent"
    const spentMatch = block.match(/\$([\d,.]+[KkMm]*\+?)\s*(?:total\s*)?spent/i);
    if (spentMatch) proposal.clientTotalSpent = "$" + spentMatch[1];

    // Hires & active — "48 hires, 13 active"
    const hiresMatch = block.match(/(\d+)\s*hires?\s*,?\s*(\d+)\s*active/i);
    if (hiresMatch) {
      proposal.clientHires = parseInt(hiresMatch[1]);
      proposal.clientActiveHires = parseInt(hiresMatch[2]);
    }

    // Avg hourly rate — "$5.15 /hr avg hourly rate paid"
    const avgRateMatch = block.match(/\$([\d,.]+)\s*\/?\s*hr\s*avg/i);
    if (avgRateMatch) proposal.clientAvgRate = "$" + avgRateMatch[1] + "/hr";

    // Total hours — "1,706 hours"
    const totalHoursMatch = block.match(/([\d,]+)\s*hours/i);
    if (totalHoursMatch) proposal.clientTotalHours = totalHoursMatch[1].replace(/,/g, "");

    // Member since — "Member since Jan 30, 2018"
    const memberMatch = block.match(/member\s*since\s*(.+?)(?:\n|$)/i);
    if (memberMatch) proposal.clientMemberSince = memberMatch[1].trim();
  }

  console.log("[UT] Proposal detail scraped:", JSON.stringify(proposal).slice(0, 500));

  if (proposal.title || proposal.coverLetter || proposal.clientNote) {
    sendToBackground("SCRAPED_PROPOSAL_DETAIL", proposal);
  }
}

// ── SCRAPER: Apply page (/nx/proposals/job/~.../apply) ──
// Binds a click-capture listener on the "Submit a Proposal" button and
// snapshots the form fields the moment the user commits to submit.
let manuallySavedApplyUrl = null;
let applyListenerBound = false;
function watchApplyPage() {
  if (applyListenerBound) return;
  applyListenerBound = true;
  console.log("[UT] Watching apply page for submit click");

  // Capture on document level so we catch the click before React handlers
  document.addEventListener("click", (ev) => {
    const btn = ev.target?.closest?.("button, [role='button']");
    if (!btn) return;
    const label = (btn.textContent || "").replace(/\s+/g, " ").trim();
    // Submit-proposal button variants on the apply page:
    //   "Send for N Connects"        (when Connects are charged)
    //   "Submit a Proposal" / "Submit Proposal"  (older / free submit)
    //   "Send Proposal"              (fallback)
    const submitPatterns = [
      /send\s+for\s+\d+\+?\s*connects?/i,
      /submit(\s+a)?\s+proposal/i,
      /send\s+proposal/i,
    ];
    if (!submitPatterns.some((re) => re.test(label))) return;

    let pending;
    try {
      pending = scrapeApplySubmission();
    } catch (e) {
      console.error("[UT] Apply scrape failed:", e);
      return;
    }
    if (!pending) return;

    // Only commit to DB if Upwork actually accepts the submit. Poll for ~6s:
    //   URL leaves /apply  → success, send
    //   validation errors visible → failure, discard
    //   timeout            → discard (safer than phantom rows)
    const startedAt = Date.now();
    const timer = setInterval(() => {
      const elapsed = Date.now() - startedAt;

      if (!window.location.href.includes("/apply")) {
        clearInterval(timer);
        if (manuallySavedApplyUrl === pending.detailUrl) {
          console.log("[UT] Auto-submit skipped — already saved manually.");
          return;
        }
        console.log("[UT] Submission confirmed by URL change; sending.");
        sendToBackground("SCRAPED_APPLY_SUBMIT", pending);
        return;
      }

      if (elapsed > 2000) {
        const errText = document.body.innerText;
        if (/\b(a cover letter is required|value is required and can't be empty|enter a rate-increase|this field is required)\b/i.test(errText)) {
          clearInterval(timer);
          console.log("[UT] Submission blocked by validation — discarded.");
          return;
        }
      }

      if (elapsed > 15000) {
        clearInterval(timer);
        console.log("[UT] Submission check timeout — discarded (no URL change).");
      }
    }, 300);
  }, true);
}

function scrapeApplySubmission() {
  const now = new Date().toISOString();
  const submission = {
    capturedAt: now,
    submittedAt: now,
    detailUrl: window.location.href,
    submittedViaExtension: true,
    section: "Submitted proposals",
  };

  // Job id/url from the apply URL
  const jobIdMatch = window.location.href.match(/\/job\/~(\w{15,})/);
  if (jobIdMatch) submission.url = "https://www.upwork.com/jobs/~" + jobIdMatch[1];
  
  const bodyText = document.body.innerText;

  // Title — try multiple strategies, in order of reliability:
  // 1a. The Upwork apply page wraps the title in:
  //       <div class="air3-card"> ← the card
  //         <header><h2>Job details</h2></header>
  //         <section class="air3-card-section">
  //           <h3>{TITLE}</h3>
  //     Find the card whose header reads "Job details", take its first <h3>.
  if (!submission.title) {
    const cards = Array.from(
      document.querySelectorAll('[class*="air3-card"], .air3-card'),
    );
    for (const card of cards) {
      const headerEl = card.querySelector("header h2, header h3, header h4, h2, h3, h4");
      if (!headerEl) continue;
      const headerText = (headerEl.textContent || "").replace(/\s+/g, " ").trim();
      if (!/^job\s*details$/i.test(headerText)) continue;
      const titleEl = Array.from(card.querySelectorAll("h3")).find((h) => {
        const t = (h.textContent || "").replace(/\s+/g, " ").trim();
        return t && !/^job\s*details$/i.test(t);
      });
      if (!titleEl) continue;
      const t = (titleEl.textContent || "").replace(/\s+/g, " ").trim();
      if (t.length < 5 || t.length > 200) continue;
      if (isBadTitle(t)) continue;
      submission.title = t;
      console.log("[UT] Title resolved via strategy 1a →", t);
      break;
    }
  }

  // 1b. Fallback: the heading directly below the "Job details" heading.
  if (!submission.title) {
    const allHeadings = Array.from(
      document.querySelectorAll("h1, h2, h3, h4, [role='heading']"),
    );
    const jobDetailsIdx = allHeadings.findIndex((h) =>
      /^job\s*details$/i.test((h.textContent || "").trim()),
    );
    if (jobDetailsIdx >= 0) {
      const sectionLabels = /^(submit|apply|send|cover letter|additional details|profile highlights|boost your proposal|about the client|job details|skills and expertise|your bid|your proposed terms|terms|rate|how often|how much|describe your|summary|proposals?|bid|client|messages|edit proposal|withdraw|view job posting|what is the rate|what is your|reactivate freelancer|hourly rate|fixed price|profile|insights)/i;
      for (let i = jobDetailsIdx + 1; i < allHeadings.length; i++) {
        const t = (allHeadings[i].textContent || "").replace(/\s+/g, " ").trim();
        if (t.length < 5 || t.length > 200) continue;
        if (isBadTitle(t)) continue;
        if (sectionLabels.test(t)) continue;
        submission.title = t;
        console.log("[UT] Title resolved via strategy 1b →", t);
        break;
      }
    }
  }

  // 2. document.title (browser tab usually carries the job title)
  if (!submission.title) {
    const tabTitle = (document.title || "").replace(/\s+/g, " ").trim();
    const tabMatch = tabTitle.match(/^(.+?)\s*[-–—]\s*Upwork/i) ||
      tabTitle.match(/^(.+?)\s*[-–—]\s*(Apply|Submit)/i);
    if (tabMatch) {
      const t = tabMatch[1].trim();
      if (t.length > 5 && t.length < 200 && !isBadTitle(t) && !/^(apply|submit|send)/i.test(t)) {
        submission.title = t;
        console.log("[UT] Title resolved via strategy 2 (tab) →", t);
      }
    }
  }

  // 3. First heading that isn't a section label (fallback)
  if (!submission.title) {
    const sectionLabels = /^(submit|apply|send|cover letter|additional details|profile highlights|boost your proposal|about the client|job details|skills and expertise|your bid|your proposed terms|terms|rate|how often|how much|describe your|summary|proposals?|bid|client|messages|edit proposal|withdraw|view job posting|what is the rate|what is your|reactivate freelancer|hourly rate|fixed price|profile|insights)/i;
    const headings = Array.from(document.querySelectorAll("h1, h2, h3"));
    for (const h of headings) {
      const t = (h.textContent || "").trim();
      if (t.length < 5 || t.length > 200) continue;
      if (isBadTitle(t)) continue;
      if (sectionLabels.test(t)) continue;
      submission.title = t;
      console.log("[UT] Title resolved via strategy 3 →", t);
      break;
    }
  }

  // 3. Parse from "Job details" block — title is usually first non-meta line
  if (!submission.title) {
    const jobDetailsMatch = bodyText.match(/job\s*details\s*\n\s*([^\n]+)/i);
    if (jobDetailsMatch) {
      const t = jobDetailsMatch[1].trim();
      if (t.length > 5 && !isBadTitle(t) && !/^(Posted|Hourly|Fixed|Entry|Intermediate|Expert|\$|Less than|More than)/i.test(t)) {
        submission.title = t;
      }
    }
  }

  // 4. Any visible /jobs/~ link with non-trivial text
  if (!submission.title) {
    const links = Array.from(document.querySelectorAll('a[href*="/jobs/~"]'));
    for (const link of links) {
      const t = link.textContent?.trim() || "";
      if (t.length > 5 && !isBadTitle(t) && !/^view\s+job/i.test(t)) {
        submission.title = t;
        break;
      }
    }
  }

  // Cover letter: combine ALL non-empty textareas on the page (Upwork's apply
  // page has "Cover Letter" + "Describe your recent experience…"). Labels are
  // prefixed so each section is identifiable when read back on the dashboard.
  const textareas = Array.from(document.querySelectorAll("textarea"));
  const coverParts = [];
  for (const ta of textareas) {
    const v = (ta.value || "").trim();
    if (v.length < 2) continue;

    let labelText = "";
    if (ta.id) {
      const lbl = document.querySelector(`label[for="${ta.id}"]`);
      if (lbl) labelText = (lbl.textContent || "").trim();
    }
    if (!labelText) {
      let parent = ta.parentElement;
      for (let i = 0; i < 4 && parent; i++) {
        const lbl = parent.querySelector("label");
        if (lbl) { labelText = (lbl.textContent || "").trim(); break; }
        parent = parent.parentElement;
      }
    }

    coverParts.push({ label: labelText, value: v });
  }
  if (coverParts.length === 1) {
    submission.coverLetter = coverParts[0].value;
  } else if (coverParts.length > 1) {
    submission.coverLetter = coverParts
      .map((p) =>
        p.label && !/^cover\s*letter$/i.test(p.label)
          ? `${p.label}:\n${p.value}`
          : p.value,
      )
      .join("\n\n");
  }

  // Proposed rate: number input near "hourly rate" label, or any $-prefixed input
  const rateInputs = Array.from(document.querySelectorAll('input[type="number"], input[type="text"]'))
    .filter((i) => {
      const nearby = (i.closest("label, [class*='field'], [class*='form-group'], div")?.innerText || "").toLowerCase();
      return /hourly|rate|bid|price/.test(nearby);
    });
  for (const input of rateInputs) {
    const v = String(input.value || "").trim();
    if (/^\d+(\.\d+)?$/.test(v)) {
      submission.proposedRate = "$" + v + (/hourly/i.test(bodyText) ? "/hr" : "");
      break;
    }
  }

  // Connects charged for this submission — from the Summary block's Total line.
  // (Not "Your bid 51 Connects or higher…" which is just the rank hint.)
  const totalMatch = bodyText.match(/Summary[\s\S]{0,400}?\bTotal\s*:?\s*\n?\s*(\d+)\s*Connects/i);
  if (totalMatch) {
    submission.bidConnects = parseInt(totalMatch[1]);
  } else {
    const reqMatch = bodyText.match(/Required\s+for\s+proposal\s*:?\s*\n?\s*(\d+)\s*Connects/i);
    if (reqMatch) submission.bidConnects = parseInt(reqMatch[1]);
  }

  // Profile used: a "Profile:" field or the selected profile label
  const profileMatch = bodyText.match(/Profile\s*:?\s*([A-Z][A-Za-z ]{2,30}\s+Profile)/);
  if (profileMatch) submission.profileUsed = profileMatch[1].trim();

  // Job category: badge near the job title
  const catBadges = document.querySelectorAll('.air3-badge, [class*="badge"], [class*="token"]');
  for (const b of catBadges) {
    const t = b.textContent?.trim() || "";
    if (t.length > 3 && t.length < 60 && /Development|Design|Writing|Marketing|Data|AI|Automation|Web|Mobile|Engineering/i.test(t)) {
      submission.jobCategory = t;
      break;
    }
  }

  // ── Job posted date ──
  const postedMatch = bodyText.match(/Posted\s+((?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2},?\s*\d{4})/i);
  if (postedMatch) submission.jobPostedDate = postedMatch[1].trim();

  // ── Job budget ──
  const hourlyRangeMatch = bodyText.match(/\$([\d,.]+)\s*[-–]\s*\$([\d,.]+)\s*\/?\s*Hourly\s*range/i);
  if (hourlyRangeMatch) {
    submission.jobBudget = `$${hourlyRangeMatch[1]} - $${hourlyRangeMatch[2]}/hr`;
  }
  if (!submission.jobBudget) {
    const fixedMatch = bodyText.match(/\$([\d,.]+)\s*\/?\s*Fixed[- ]?price/i);
    if (fixedMatch) submission.jobBudget = "$" + fixedMatch[1];
  }

  // ── Experience level / hours / duration ──
  const expMatch = bodyText.match(/(Entry[\s-]?level|Intermediate|Expert)\s*\/?\s*Experience\s*level/i) ||
    bodyText.match(/\b(Entry[\s-]?level|Intermediate|Expert)\b/);
  if (expMatch) submission.jobExperienceLevel = expMatch[1].trim();

  const hoursMatch = bodyText.match(/((?:Less than|More than)?\s*\d+\s*hrs?\s*\/\s*week)\s*\/?\s*Hourly/i) ||
    bodyText.match(/((?:Less than|More than)?\s*\d+\s*hrs?\s*\/\s*week)/i);
  if (hoursMatch) submission.jobHoursPerWeek = hoursMatch[1].trim();

  const durationMatch = bodyText.match(/((?:\d+\s*to\s*\d+\s*(?:months?|weeks?|days?)|Less than (?:a )?(?:month|week)|More than \d+ months?))\s*\/?\s*Project\s*length/i) ||
    bodyText.match(/((?:\d+\s*to\s*\d+\s*(?:months?|weeks?|days?)))/i);
  if (durationMatch) submission.jobDuration = durationMatch[1].trim();

  // ── Job description — parse block under "Job details" heading ──
  const descMatch = bodyText.match(/job\s*details\s*\n([\s\S]*?)(?=\nSkills and expertise|\nView job posting|\nBoost your proposal|\nProfile highlights|\nBoosted proposal|\nCover letter|\nYour proposed|$)/i);
  if (descMatch) {
    let desc = descMatch[1].trim();
    const descLines = desc.split("\n").filter((l) => {
      const trimmed = l.trim();
      if (!trimmed) return false;
      if (/^\$[\d,.]+\s*[-–]/.test(trimmed)) return false;
      if (/^\$[\d,.]+\s*$/.test(trimmed)) return false;
      if (/Experience\s*level$/i.test(trimmed)) return false;
      if (/Hourly\s*range$/i.test(trimmed)) return false;
      if (/Fixed[- ]?price$/i.test(trimmed)) return false;
      if (/hrs?\s*\/\s*week/i.test(trimmed)) return false;
      if (/Project\s*length$/i.test(trimmed)) return false;
      if (/Posted\s+(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)/i.test(trimmed)) return false;
      if (/^(Intermediate|Expert|Entry[\s-]?level)$/i.test(trimmed)) return false;
      if (/^(Hourly|Fixed-price|Less than|More than)$/i.test(trimmed)) return false;
      if (/^\d+\s*to\s*\d+\s*months?$/i.test(trimmed)) return false;
      if (/^(less|more|show\s+less|show\s+more|read\s+less|read\s+more)$/i.test(trimmed)) return false;
      if (/^more\s*\/\s*less\s+about/i.test(trimmed)) return false;
      return true;
    });
    if (descLines.length > 1 && submission.title && descLines[0].includes(submission.title)) {
      descLines.shift();
    }
    if (descLines.length > 1 && submission.jobCategory && descLines[0].includes(submission.jobCategory)) {
      descLines.shift();
    }
    desc = descLines.join("\n").trim().replace(/\n{3,}/g, "\n\n");
    desc = desc
      .replace(/\s*more\s*\/\s*less\s+about\s*\S*\s*$/i, "")
      .replace(/\s*\b(show|read)\s+(less|more)\b\s*$/i, "")
      .replace(/\s+\b(less|more)\b\s*$/i, "")
      .trim();
    if (desc.length > 10) submission.jobDescription = desc;
  }

  // ── Skills ──
  // Prefer Upwork's official skill markers; fall back to generic badges.
  let skillEls = document.querySelectorAll('[data-qa-skill-key], [data-qa-skill-uid]');
  if (skillEls.length === 0) {
    skillEls = document.querySelectorAll('.air3-badge, [class*="skill-badge"], [data-test="skill"], .up-skill-badge, [class*="air3-token"]');
  }
  const badgeSkills = Array.from(skillEls)
    .map((el) => el.textContent.replace(/\s+/g, " ").trim())
    .filter((s) =>
      s.length > 1 &&
      s.length < 50 &&
      !/^(Boosted|Boost outbid|General|Specialized|New)$/i.test(s) &&
      !/connects?\b/i.test(s) &&
      !/\bbalance\b/i.test(s) &&
      !/\bremaining\b/i.test(s) &&
      !/^\$?\d+(\.\d+)?$/.test(s),
    );
  if (badgeSkills.length > 0) {
    submission.jobSkills = [...new Set(badgeSkills)].slice(0, 30);
  }
  // Remove skill names from description if they leaked in
  if (submission.jobDescription && submission.jobSkills?.length) {
    let cleanDesc = submission.jobDescription;
    for (const skill of submission.jobSkills) {
      cleanDesc = cleanDesc.replace(new RegExp("^\\s*" + skill.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "\\s*$", "gim"), "");
    }
    submission.jobDescription = cleanDesc.replace(/\n{3,}/g, "\n\n").trim();
  }

  // ── Client name ──
  const clientNameMatch = bodyText.match(/(?:^|\n)\s*Client\s*\n\s*(.+?)(?:\n|$)/);
  if (clientNameMatch) {
    const name = clientNameMatch[1].trim();
    if (name.length > 1 && name.length < 100 && !/payment|phone|verified|about\s*the/i.test(name)) {
      submission.clientName = name;
    }
  }

  // ── About the client — full block parse ──
  const aboutMatch = bodyText.match(/about\s*the\s*client([\s\S]*?)(?=\n\s*job\s*link|\n\s*similar\s*jobs|\n\s*how\s*it\s*works|\n\s*activity\s*on\s*this\s*job|\n\s*send\s+for|\n\s*send\s+proposal|\n\s*cancel|$)/i);
  if (aboutMatch) {
    const block = aboutMatch[1];
    const lines = block.split("\n").map((l) => l.trim()).filter(Boolean);

    submission.clientPaymentVerified = /payment\s*(?:method\s*)?verified/i.test(block);

    const ratingLine = lines.find((l) => /^\d+\.\d+$/.test(l));
    if (ratingLine) submission.clientRating = parseFloat(ratingLine);

    const reviewMatch = block.match(/([\d.]+)\s*of\s*(\d+)\s*reviews?/i);
    if (reviewMatch) {
      submission.clientReviewScore = reviewMatch[0].trim();
      submission.clientReviews = parseInt(reviewMatch[2]);
      if (!submission.clientRating) submission.clientRating = parseFloat(reviewMatch[1]);
    }

    const countryIdx = lines.findIndex((l) =>
      /^[A-Z]{2,4}$/.test(l) ||
      /^(United States|United Kingdom|Canada|Australia|India|Pakistan|Germany|France|Thailand|Philippines|Singapore|Netherlands|Israel|Brazil|Japan|China|South Korea|Spain|Italy|Sweden|Norway|Denmark|Switzerland|Ireland|New Zealand|Mexico|Argentina|Colombia|Chile|Egypt|Nigeria|Kenya|South Africa|UAE|Saudi Arabia|Bangladesh|Sri Lanka|Vietnam|Indonesia|Malaysia|Turkey|Poland|Ukraine|Romania|Czech Republic|Hungary|Portugal|Greece|Belgium|Austria|Finland|Russia|Belarus|Georgia|Armenia|Azerbaijan|Jordan|Lebanon|Qatar|Bahrain|Kuwait|Oman|Luxembourg)$/i.test(l)
    );
    if (countryIdx !== -1) {
      submission.clientCountry = lines[countryIdx];
      const nextLine = lines[countryIdx + 1];
      if (nextLine) {
        const cityMatch = nextLine.match(/^(.+?)\s{2,}/) || nextLine.match(/^(.+?)\s+\d{1,2}:\d{2}\s*(AM|PM|am|pm)/);
        if (cityMatch) submission.clientCity = cityMatch[1].trim();
      }
    }

    const jobsPostedMatch = block.match(/(\d+)\s*jobs?\s*posted/i);
    if (jobsPostedMatch) submission.clientJobsPosted = parseInt(jobsPostedMatch[1]);

    const hireRateMatch = block.match(/(\d+)%\s*hire\s*rate/i);
    if (hireRateMatch) submission.clientHireRate = parseInt(hireRateMatch[1]);
    const openJobsMatch = block.match(/(\d+)\s*open\s*jobs?/i);
    if (openJobsMatch) submission.clientOpenJobs = parseInt(openJobsMatch[1]);

    const spentMatch = block.match(/\$([\d,.]+[KkMm]*\+?)\s*(?:total\s*)?spent/i);
    if (spentMatch) submission.clientTotalSpent = "$" + spentMatch[1];

    const hiresMatch = block.match(/(\d+)\s*hires?\s*,?\s*(\d+)\s*active/i);
    if (hiresMatch) {
      submission.clientHires = parseInt(hiresMatch[1]);
      submission.clientActiveHires = parseInt(hiresMatch[2]);
    }

    const avgRateMatch = block.match(/\$([\d,.]+)\s*\/?\s*hr\s*avg/i);
    if (avgRateMatch) submission.clientAvgRate = "$" + avgRateMatch[1] + "/hr";

    const totalHoursMatch = block.match(/([\d,]+)\s*hours/i);
    if (totalHoursMatch) submission.clientTotalHours = totalHoursMatch[1].replace(/,/g, "");

    const memberMatch = block.match(/member\s*since\s*(.+?)(?:\n|$)/i);
    if (memberMatch) submission.clientMemberSince = memberMatch[1].trim();
  }

  console.log("[UT] Apply submission scraped:", JSON.stringify(submission).slice(0, 800));

  if (submission.title || submission.coverLetter) return submission;
  return null;
}

// ── SCRAPER: Job Feed ──
function scrapeFeed() {
  console.log("[UT] Scraping job feed...");

  const jobs = [];
  const jobLinks = document.querySelectorAll('a[href*="/jobs/~"]');
  const seen = new Set();

  for (const link of jobLinks) {
    const href = link.href;
    const title = link.textContent.trim();

    // Skip bad titles
    if (isBadTitle(title)) continue;

    // Clean URL — strip query params for dedup
    const cleanHref = href.split("?")[0];
    if (seen.has(cleanHref)) continue;
    seen.add(cleanHref);

    if (title.length > 300) continue;

    // Skip links inside the detail panel — only scrape from the feed list
    const inPanel = link.closest('[class*="drawer"], [class*="panel"], [class*="slider"], [role="dialog"]');
    if (inPanel) continue;

    const job = { title, url: cleanHref };
    const card = link.closest("article, section, [class*='card'], [class*='tile'], [class*='job'], div[class]");
    if (card) {
      const cardText = card.innerText;
      const budgetMatch = cardText.match(/(?:est\.?\s*budget|budget)\s*:?\s*\$?([\d,]+)/i);
      if (budgetMatch) job.budget = "$" + budgetMatch[1];
      if (!job.budget) {
        const hourlyMatch = cardText.match(/\$([\d,.]+)\s*[-–]\s*\$([\d,.]+)/);
        if (hourlyMatch) job.budget = `$${hourlyMatch[1]} - $${hourlyMatch[2]}`;
      }
      if (/fixed.price/i.test(cardText)) job.jobType = "fixed";
      else if (/hourly/i.test(cardText)) job.jobType = "hourly";
      const levelMatch = cardText.match(/(entry[\s-]level|intermediate|expert)/i);
      if (levelMatch) job.experienceLevel = levelMatch[1];
      const skillEls = card.querySelectorAll('.air3-badge, [class*="skill"], .up-skill-badge');
      if (skillEls.length > 0) {
        job.skills = Array.from(skillEls).map((el) => el.textContent.trim()).filter((s) => s.length > 0 && s.length < 50).slice(0, 15);
      }
    }
    jobs.push(job);
  }

  if (jobs.length > 0) {
    console.log("[UT] Found", jobs.length, "jobs in feed");
    sendToBackground("SCRAPED_FEED", { jobs: jobs.slice(0, 50), capturedAt: new Date().toISOString() });
  }
}

// ── Detect if a job detail panel/drawer is open ──
function isJobPanelOpen() {
  // Look for "Open job in a new window" link — indicates job detail is showing
  const openLink = document.querySelector('a[href*="/jobs/~"]');
  if (openLink && /open\s*job/i.test(openLink.textContent)) return true;

  // Look for a visible panel/drawer with job-like content
  const panels = document.querySelectorAll('[class*="drawer"], [class*="panel"], [class*="slider"], [role="dialog"]');
  for (const p of panels) {
    if (p.offsetHeight > 200 && p.innerText.includes("Send a proposal")) return true;
  }

  return false;
}

// Track which job URLs we already scraped in this session to avoid duplicates
const scrapedJobUrls = new Set();
// Track the last job URL shown in the criteria panel (separate from scrape dedup)
let lastJobPanelUrl = null;

// ── Always try to identify the user on ANY page ──
function identifyUser() {
  // Try all sources to find a userId
  const userId = extractUserId();
  if (userId) {
    console.log("[UT] User identified:", userId);
    sendToBackground("SAVE_ACCOUNT_INFO", { userId });
    return;
  }

  // Also look for the user's name in the nav bar (top-right profile area)
  const navProfileLink = document.querySelector('a[href*="/freelancers/~"]');
  if (navProfileLink) {
    const m = navProfileLink.href.match(/\/freelancers\/~(\w+)/);
    if (m) {
      console.log("[UT] User identified from nav link:", m[1]);
      sendToBackground("SAVE_ACCOUNT_INFO", { userId: m[1], name: navProfileLink.textContent.trim() || null });
      return;
    }
  }

  // Try getting it from the page's fetch headers or embedded data
  const allScripts = document.querySelectorAll("script");
  for (const s of allScripts) {
    const text = s.textContent || "";
    // Look for visitor/user ID patterns in any script
    const match = text.match(/"(?:visitorId|userId|uid|personUid|ciphertext|freelancerId)"\s*:\s*"?(\w{10,})"?/);
    if (match) {
      console.log("[UT] User identified from script tag:", match[1]);
      sendToBackground("SAVE_ACCOUNT_INFO", { userId: match[1] });
      return;
    }
  }

  console.log("[UT] Could not identify user on this page");
}

// ── SCRAPER: Messages page (/ab/messages/ or /nx/messages/) ──
function scrapeMessages() {
  console.log("[UT] Scraping messages page...");

  const messages = [];

  // ── 1. SIDEBAR: Scrape conversation list ──
  // Each conversation in the left sidebar shows:
  //   "Abdullah Javaid, A...  2/25/26"
  //   "Build a Simple AI Automation t..."
  //   "You: Abdullah Javaid ?"   ← "You:" prefix = freelancer replied
  // Rows are links to /ab/messages/rooms/room_xxx

  const roomLinks = document.querySelectorAll('a[href*="/messages/rooms/"], a[href*="/rooms/room_"]');
  const seenRooms = new Set();

  for (const link of roomLinks) {
    const href = link.href;
    const roomMatch = href.match(/room_[a-f0-9]+/);
    if (!roomMatch || seenRooms.has(roomMatch[0])) continue;
    seenRooms.add(roomMatch[0]);

    // Read text from the link itself — Nuxt wraps the full sidebar card inside <a>.
    // Only walk up if the link is too short, and stop before a parent contains another room link.
    let text = (link.innerText || "").trim();
    if (text.length < 20) {
      let node = link.parentElement;
      while (node && node !== document.body) {
        if (node.querySelectorAll('a[href*="/messages/rooms/"]').length > 1) break;
        const t = (node.innerText || "").trim();
        if (t.length > text.length) { text = t; }
        if (text.length > 20) break;
        node = node.parentElement;
      }
    }
    const lines = text.split("\n").map((l) => l.trim()).filter(Boolean);
    // Strip leading avatar initials (e.g. "AF" when the row has no profile photo)
    while (lines.length && /^[A-Z]{1,3}$/.test(lines[0])) lines.shift();
    if (lines.length < 2) continue;

    const msg = {
      type: "message",
      roomId: roomMatch[0],
      url: href.split("?")[0],
    };

    // Line 1: "Abdullah Javaid, A...  2/25/26" — name + date
    const firstLine = lines[0];
    const nameDateMatch = firstLine.match(/^(.+?)\s+(\d{1,2}\/\d{1,2}\/\d{2,4})$/);
    if (nameDateMatch) {
      msg.senderName = nameDateMatch[1].trim();
      msg.date = nameDateMatch[2];
    } else {
      msg.senderName = firstLine.slice(0, 60);
    }

    msg.freelancerReplied = true; // default safe
    msg.jobTitle = null;
    msg.preview = null;

    for (let li = 1; li < lines.length; li++) {
      const line = lines[li];

      if (/^You\s*:/i.test(line)) {
        msg.preview = line.slice(0, 200);
        msg.freelancerReplied = true;
        break;
      }

      if (/ended the|declined|sent an offer|accepted|started|completed|closed|left feedback/i.test(line)) {
        msg.preview = line.slice(0, 200);
        msg.freelancerReplied = true;
        break;
      }

      if (/^\d{1,2}\/\d{1,2}\/\d{2,4}$/.test(line)) continue;

      if (!msg.jobTitle) {
        msg.jobTitle = line;
        continue;
      }

      if (!msg.preview) {
        msg.preview = line.slice(0, 200);
        msg.freelancerReplied = false;
        break;
      }
    }

    // Strict unread detection — only trust aria-label. Bold/dot heuristics
    // false-positive on initials and system-action text.
    const ariaLabel = (link.getAttribute("aria-label") || "").toLowerCase();
    msg.isUnread = /\bunread\b|\bnew message\b/.test(ariaLabel);

    msg.title = `Message from ${msg.senderName || "Unknown"}`;
    messages.push(msg);
  }

  // Split: conversations needing attention vs already replied
  const needAttention = messages.filter((m) => !m.freelancerReplied || m.isUnread);
  const nowReplied = messages.filter((m) => m.freelancerReplied && !m.isUnread);

  console.log("[UT] Scraped", messages.length, "conversations,", needAttention.length, "need attention,", nowReplied.length, "replied");
  console.log("[UT] Conversations:", messages.map((m) => `${m.senderName}: replied=${m.freelancerReplied}, unread=${m.isUnread}`).join(" | "));

  if (needAttention.length > 0 || nowReplied.length > 0) {
    sendToBackground("SCRAPED_MESSAGES", {
      needAttention: needAttention.map((m) => ({
        ...m,
        needsAttention: true,
      })),
      nowReplied: nowReplied.map((m) => ({
        ...m,
        needsAttention: false,
      })),
    });
  }
}

// ── SCRAPER: Apply page (/nx/proposals/job/~.../apply/) ──
function scrapeApplyPage() {
  // Cover letter — typically the only <textarea> on this page
  let coverLetter = "";
  const coverLabel = Array.from(document.querySelectorAll('label, h2, h3, h4, span, div'))
    .find((el) => el.textContent.trim() === "Cover Letter");
  if (coverLabel) {
    let container = coverLabel.parentElement;
    let textarea = null;
    while (container && !textarea) {
      textarea = container.querySelector('textarea');
      container = container.parentElement;
    }
    if (textarea) coverLetter = textarea.value || "";
  }
  if (!coverLetter) {
    const ta = document.querySelector('textarea');
    if (ta) coverLetter = ta.value || "";
  }

  // Job details — multi-strategy
  let jobTitle = "", jobDescription = "", jobCategory = "",
      budget = "", experienceLevel = "", projectLength = "";

  // Strategy 1: find ANY element whose text is exactly "Job details"
  let jobSection = null;
  const allEls = document.querySelectorAll('h1, h2, h3, h4, h5, h6, div, span, [role="heading"]');
  for (const el of allEls) {
    if (el.textContent.trim() === "Job details") {
      let container = el.closest('section') || el.parentElement;
      // Walk up until we get a container with substantial text
      while (container && (container.innerText || "").length < 300 && container.parentElement) {
        container = container.parentElement;
      }
      jobSection = container;
      break;
    }
  }

  // Strategy 2: anchor on "View job posting" link and walk up
  if (!jobSection) {
    const viewLink = Array.from(document.querySelectorAll('a, button'))
      .find((el) => /^view job posting/i.test(el.textContent.trim()));
    if (viewLink) {
      let container = viewLink.parentElement;
      while (container && (container.innerText || "").length < 500 && container.parentElement) {
        container = container.parentElement;
      }
      jobSection = container;
    }
  }

  // Strategy 3: whole body, minus the cover letter
  let sourceText = jobSection ? (jobSection.innerText || "") : (document.body.innerText || "");
  if (!jobSection && coverLetter) sourceText = sourceText.replace(coverLetter, "");

  // Title: prefer the first non-"Job details" heading inside the section
  if (jobSection) {
    const innerHeadings = jobSection.querySelectorAll('h1, h2, h3');
    for (const h of innerHeadings) {
      const t = h.textContent.trim();
      if (t && t !== "Job details" && t.length > 3 && t.length < 200) { jobTitle = t; break; }
    }
  }

  const lines = sourceText.split("\n").map((l) => l.trim()).filter(Boolean);

  // Sidebar metadata (works regardless of which strategy found the section)
  for (let i = 0; i < lines.length; i++) {
    const l = lines[i];
    if (!experienceLevel && /^(Entry level|Intermediate|Expert)$/i.test(l)) experienceLevel = l;
    if (!budget && /^\$[\d,.]+/.test(l) && /fixed|hour/i.test(lines[i + 1] || "")) budget = l;
    if (!projectLength && /(Less than|1 to|3 to|More than).*month/i.test(l)) projectLength = l;
  }

  // Description: skip known boilerplate, keep everything else
  const skipExact = new Set([
    "Job details", "Experience level", "Project length", "Fixed-price", "Hourly",
    "less", "more", "Intermediate", "Entry level", "Expert",
    jobTitle, experienceLevel, budget, projectLength,
  ].filter(Boolean));
  const skipPrefix = /^(Posted |View job posting|Upgrade now|Reactivate )/i;

  const titleIdx = jobTitle ? lines.findIndex((l) => l === jobTitle) : -1;
  const startIdx = titleIdx >= 0 ? titleIdx + 1 : 0;
  const descLines = [];
  for (let i = startIdx; i < lines.length; i++) {
    const l = lines[i];
    if (skipExact.has(l)) continue;
    if (skipPrefix.test(l)) continue;
    if (l === jobCategory) continue;
    descLines.push(l);
  }
  jobDescription = descLines.join("\n").trim();

  // Category — chip/badge inside the section
  if (jobSection) {
    const chips = jobSection.querySelectorAll('button, [class*="chip"], [class*="badge"], [class*="pill"], [class*="tag"]');
    for (const c of chips) {
      const t = c.textContent.trim();
      if (t && t.length > 3 && t.length < 50 && t !== jobTitle &&
          !/posted|view|less|more|upgrade|reactivate|cover letter|attach/i.test(t)) {
        jobCategory = t; break;
      }
    }
  }

  console.log("[UT] Apply page scraped:", {
    coverLetterLen: coverLetter.length,
    jobTitle, jobCategory, budget, experienceLevel, projectLength,
    descLen: jobDescription.length,
    sectionFound: !!jobSection,
  });

  return { coverLetter, jobTitle, jobDescription, jobCategory, budget, experienceLevel, projectLength };
}

// ── PANEL: Floating "Analyze Cover Letter" widget on apply pages ──
let analysisPanelInjected = false;
function injectAnalysisPanel() {
  if (analysisPanelInjected) return;
  if (document.getElementById("ut-analysis-panel")) { analysisPanelInjected = true; return; }
  analysisPanelInjected = true;

  const panel = document.createElement("div");
  panel.id = "ut-analysis-panel";
  panel.setAttribute("style", [
    "position:fixed", "right:20px", "bottom:20px", "width:380px", "max-height:75vh",
    "background:#ffffff", "color:#0e1925", "border:1px solid #d5dde5", "border-radius:12px",
    "box-shadow:0 10px 40px rgba(14,25,37,0.18)", "z-index:2147483647",
    "font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif",
    "font-size:14px", "display:flex", "flex-direction:column", "overflow:hidden",
  ].join(";"));

  panel.innerHTML = `
    <div id="ut-panel-header" style="display:flex;align-items:center;justify-content:space-between;padding:12px 14px;background:#108a00;color:#fff;cursor:move;">
      <div style="font-weight:600;font-size:14px;">Cover Letter Analyzer</div>
      <div style="display:flex;gap:8px;">
        <button id="ut-panel-min" style="background:transparent;color:#fff;border:0;cursor:pointer;font-size:18px;line-height:1;padding:0 4px;" title="Minimize">—</button>
        <button id="ut-panel-close" style="background:transparent;color:#fff;border:0;cursor:pointer;font-size:18px;line-height:1;padding:0 4px;" title="Close">✕</button>
      </div>
    </div>
    <div id="ut-panel-body" style="padding:14px;overflow-y:auto;flex:1;">
      <button id="ut-analyze-btn" style="width:100%;padding:10px 14px;background:#108a00;color:#fff;border:0;border-radius:8px;font-weight:600;cursor:pointer;font-size:14px;">Analyze Cover Letter</button>
      <div id="ut-status" style="margin-top:10px;color:#5e6d7e;font-size:12px;"></div>
      <div id="ut-results" style="margin-top:14px;"></div>
    </div>
  `;
  document.body.appendChild(panel);

  // Drag
  const header = panel.querySelector("#ut-panel-header");
  let dragging = false, offX = 0, offY = 0;
  header.addEventListener("mousedown", (e) => {
    if (e.target.tagName === "BUTTON") return;
    dragging = true;
    const rect = panel.getBoundingClientRect();
    offX = e.clientX - rect.left;
    offY = e.clientY - rect.top;
    e.preventDefault();
  });
  document.addEventListener("mousemove", (e) => {
    if (!dragging) return;
    panel.style.left = (e.clientX - offX) + "px";
    panel.style.top = (e.clientY - offY) + "px";
    panel.style.right = "auto";
    panel.style.bottom = "auto";
  });
  document.addEventListener("mouseup", () => { dragging = false; });

  // Minimize/close
  const body = panel.querySelector("#ut-panel-body");
  panel.querySelector("#ut-panel-min").addEventListener("click", () => {
    body.style.display = body.style.display === "none" ? "block" : "none";
  });
  panel.querySelector("#ut-panel-close").addEventListener("click", () => {
    panel.remove();
    analysisPanelInjected = false;
  });

  // Analyze
  panel.querySelector("#ut-analyze-btn").addEventListener("click", () => {
    runAnalysis(panel);
  });
}

let inlineSaveButtonInjected = false;
let inlineSaveObserver = null;
let submitBlockObserver = null;

function expandJobDescriptionOnly() {
  let container = document.querySelector(
    '[data-test="job-description"], [data-test="JobDescription"], [data-test="JobDetails"], [class*="job-description"], [class*="JobDescription"], [class*="job-details"]',
  );
  if (!container) {
    const headings = Array.from(document.querySelectorAll("h1, h2, h3, h4, h5, h6, [role='heading']"));
    const heading = headings.find((h) => /^job\s*details$/i.test((h.textContent || "").trim()));
    if (heading) {
      container =
        heading.closest("section, [class*='section'], [class*='card'], [class*='panel']") ||
        heading.parentElement;
    }
  }
  if (!container) return false;

  const triggers = Array.from(container.querySelectorAll('*'));
  let clicked = 0;
  for (const t of triggers) {
    if (t.children.length > 0) continue;
    const text = (t.textContent || "").replace(/\s+/g, " ").trim();
    if (!/^(learn more|read more|see more|show more|more)$/i.test(text)) continue;
    if (t.tagName === "A") {
      const href = t.getAttribute("href");
      if (href && !/^#?$|^javascript:/i.test(href)) continue;
    }
    try { t.click(); clicked++; } catch {}
  }
  return clicked > 0;
}

const submitRe = /send\s+for\s+\d+\+?\s*connects?|submit(\s+a)?\s+proposal|send\s+proposal/i;

function injectInlineSaveButton() {
  if (inlineSaveButtonInjected) return;
  expandJobDescriptionOnly();

  const tryInject = () => {
    if (document.getElementById("ut-inline-save")) {
      inlineSaveButtonInjected = true;
      return true;
    }
    const submit = Array.from(document.querySelectorAll('button, [role="button"]')).find((b) => {
      const t = (b.textContent || "").replace(/\s+/g, " ").trim();
      return submitRe.test(t);
    });
    if (!submit || !submit.parentElement) return false;

    // Disable submit until tracker save succeeds — keep re-disabling if React overrides it
    submit.disabled = true;
    submit.dataset.utBlocked = "1";
    submitBlockObserver = new MutationObserver(() => {
      if (submit.dataset.utBlocked && !submit.disabled) submit.disabled = true;
    });
    submitBlockObserver.observe(submit, { attributes: true, attributeFilter: ["disabled"] });

    const wrap = document.createElement("span");
    wrap.id = "ut-inline-save-wrap";
    wrap.style.cssText = "display:inline-flex;align-items:center;gap:12px;margin-left:12px;vertical-align:middle;";

    const btn = document.createElement("button");
    btn.id = "ut-inline-save";
    btn.type = "button";
    btn.textContent = "Save to Tracker";
    btn.style.cssText = [
      "padding:11.7px 18px",
      "background:#0e1925",
      "color:#fff",
      "border:0",
      "border-radius:999px",
      "font-weight:600",
      "cursor:pointer",
      "font-size:14px",
      "font-family:inherit",
      "line-height:1.2",
    ].join(";");

    const status = document.createElement("span");
    status.id = "ut-inline-save-status";
    status.style.cssText = "font-size:12px;color:#5e6d7e;font-family:inherit;";
    status.textContent = "Save to Tracker before submitting";

    btn.addEventListener("click", () => saveApplyToTrackerInline(btn, status));

    wrap.appendChild(btn);
    wrap.appendChild(status);
    submit.parentElement.insertBefore(wrap, submit.nextSibling);
    inlineSaveButtonInjected = true;
    return true;
  };

  if (tryInject()) return;

  inlineSaveObserver = new MutationObserver(() => {
    if (tryInject() && inlineSaveObserver) {
      inlineSaveObserver.disconnect();
      inlineSaveObserver = null;
    }
  });
  inlineSaveObserver.observe(document.body, { childList: true, subtree: true });
}

function showSaveOverlay() {
  if (document.getElementById("ut-save-overlay")) return;
  const overlay = document.createElement("div");
  overlay.id = "ut-save-overlay";
  overlay.style.cssText = [
    "position:fixed", "top:0", "left:0", "right:0", "bottom:0",
    "background:rgba(14,25,37,0.55)",
    "z-index:2147483647",
    "display:flex", "align-items:center", "justify-content:center",
    "font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif",
    "color:#fff",
    "cursor:wait",
  ].join(";");
  overlay.innerHTML = `
    <div style="display:flex;flex-direction:column;align-items:center;gap:16px;">
      <div style="width:48px;height:48px;border:4px solid rgba(255,255,255,0.25);border-top-color:#fff;border-radius:50%;animation:ut-save-spin 0.8s linear infinite;"></div>
      <div style="font-weight:600;font-size:16px;">Saving proposal…</div>
    </div>
    <style>@keyframes ut-save-spin { to { transform: rotate(360deg); } }</style>
  `;
  document.body.appendChild(overlay);
}

function hideSaveOverlay() {
  const o = document.getElementById("ut-save-overlay");
  if (o) o.remove();
}

async function saveApplyToTrackerInline(btn, status) {
  status.style.color = "#5e6d7e";
  status.textContent = "Saving…";
  showSaveOverlay();

  if (expandJobDescriptionOnly()) {
    await new Promise((r) => setTimeout(r, 300));
  }

  let pending;
  try {
    pending = scrapeApplySubmission();
  } catch (e) {
    status.style.color = "#c0392b";
    status.textContent = "Could not read proposal";
    hideSaveOverlay();
    return;
  }
  if (!pending) {
    status.style.color = "#c0392b";
    status.textContent = "No proposal data found";
    hideSaveOverlay();
    return;
  }
  if (!pending.coverLetter) {
    status.style.color = "#c0392b";
    status.textContent = "Cover letter empty";
    hideSaveOverlay();
    return;
  }

  manuallySavedApplyUrl = pending.detailUrl;
  btn.disabled = true;
  btn.style.opacity = "0.6";
  chrome.runtime.sendMessage(
    { type: "SCRAPED_APPLY_SUBMIT", payload: pending },
    (res) => {
      hideSaveOverlay();
      if (chrome.runtime.lastError || (res && res.ok === false)) {
        status.style.color = "#c0392b";
        status.textContent = "Save failed";
        btn.disabled = false;
        btn.style.opacity = "1";
        manuallySavedApplyUrl = null;
        return;
      }
      status.style.color = "#108a00";
      status.textContent = "Saved ✓";
      // Unblock the submit button
      submitBlockObserver?.disconnect();
      submitBlockObserver = null;
      const submitBtn = Array.from(document.querySelectorAll('button, [role="button"]')).find((b) =>
        submitRe.test((b.textContent || "").replace(/\s+/g, " ").trim())
      );
      if (submitBtn && submitBtn.dataset.utBlocked) {
        delete submitBtn.dataset.utBlocked;
        submitBtn.disabled = false;
      }
    },
  );
}

function runAnalysis(panel) {
  const status = panel.querySelector("#ut-status");
  const results = panel.querySelector("#ut-results");
  const btn = panel.querySelector("#ut-analyze-btn");

  const data = scrapeApplyPage();
  if (!data.coverLetter || data.coverLetter.trim().length < 10) {
    status.textContent = "Cover letter is empty or too short to analyze.";
    status.style.color = "#c0392b";
    results.innerHTML = "";
    return;
  }
  if (!data.jobDescription) {
    status.textContent = "Couldn't find the job description on this page.";
    status.style.color = "#c0392b";
    results.innerHTML = "";
    return;
  }

  btn.disabled = true;
  btn.textContent = "Analyzing…";
  btn.style.background = "#5e6d7e";
  status.textContent = `Sending ${data.coverLetter.length} chars to Gemini…`;
  status.style.color = "#5e6d7e";
  results.innerHTML = "";

  chrome.runtime.sendMessage({ type: "ANALYZE_COVER_LETTER", payload: data }, (r) => {
    btn.disabled = false;
    btn.textContent = "Re-analyze";
    btn.style.background = "#108a00";
    if (chrome.runtime.lastError) {
      status.textContent = "Extension error: " + chrome.runtime.lastError.message;
      status.style.color = "#c0392b";
      return;
    }
    if (!r || !r.ok) {
      status.textContent = "Analyze failed: " + (r?.error || "unknown error");
      status.style.color = "#c0392b";
      if (r?.detail) status.textContent += " — " + r.detail;
      return;
    }
    status.textContent = "";
    renderAnalysis(results, r.analysis);
  });
}

function renderAnalysis(container, a) {
  if (!a) { container.innerHTML = "<div style='color:#c0392b;'>Empty analysis.</div>"; return; }
  const score = Number(a.score) || 0;
  const scoreColor = score >= 80 ? "#108a00" : score >= 60 ? "#d49000" : "#c0392b";
  const sevColor = { critical: "#c0392b", major: "#d49000", minor: "#5e6d7e" };
  const esc = (s) => String(s || "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  let html = "";
  html += `<div style="display:flex;align-items:baseline;gap:10px;margin-bottom:10px;">
    <div style="font-size:38px;font-weight:700;color:${scoreColor};line-height:1;">${score}</div>
    <div style="color:#5e6d7e;font-size:12px;">/100</div>
  </div>`;
  if (a.summary) {
    html += `<div style="margin-bottom:14px;color:#0e1925;line-height:1.45;">${esc(a.summary)}</div>`;
  }
  if (Array.isArray(a.strengths) && a.strengths.length) {
    html += `<div style="margin-bottom:12px;"><div style="font-weight:600;margin-bottom:6px;color:#108a00;">Strengths</div><ul style="margin:0;padding-left:18px;color:#0e1925;">`;
    for (const s of a.strengths) html += `<li style="margin-bottom:4px;">${esc(s)}</li>`;
    html += `</ul></div>`;
  }
  if (Array.isArray(a.issues) && a.issues.length) {
    html += `<div><div style="font-weight:600;margin-bottom:6px;">Issues (${a.issues.length})</div>`;
    for (const i of a.issues) {
      const c = sevColor[i.severity] || "#5e6d7e";
      html += `<div style="border-left:3px solid ${c};padding:8px 10px;margin-bottom:8px;background:#f7f9fb;border-radius:4px;">
        <div style="display:flex;gap:6px;align-items:center;margin-bottom:4px;">
          <span style="font-size:10px;font-weight:700;text-transform:uppercase;color:${c};">${esc(i.severity)}</span>
          <span style="font-size:10px;color:#5e6d7e;text-transform:uppercase;">${esc(i.category)}</span>
        </div>
        <div style="margin-bottom:6px;color:#0e1925;line-height:1.4;">${esc(i.message)}</div>
        <div style="font-size:12px;color:#5e6d7e;line-height:1.4;"><b>Fix:</b> ${esc(i.fix)}</div>
      </div>`;
    }
    html += `</div>`;
  } else {
    html += `<div style="color:#108a00;">No issues found.</div>`;
  }
  container.innerHTML = html;
}

// ── Helpers ──
function isFeedPage(url) {
  return (
    url.includes("/nx/find-work") ||
    url.includes("/ab/find-work") ||
    url.includes("/search/jobs") ||
    url.includes("/nx/s/universal-search/jobs")
  );
}

// ── Page router ──
function detectPageAndScrape() {
  const url = window.location.href;
  console.log("[UT] Detecting page type for:", url);

  // ALWAYS try to identify the user on every page
  identifyUser();

  // Full profile scraping only on freelancer profile page
  if (url.includes("/freelancers/")) {
    const pageProfileId = url.match(/\/freelancers\/~(\w+)/)?.[1];
    chrome.storage.local.get(["canonicalUserId"], (data) => {
      if (!data.canonicalUserId) {
        console.log("[UT] Skip profile scrape: no canonical user yet");
        return;
      }
      // Fail closed: only scrape when the profile id in the URL is known
      // AND matches the locked canonical (logged-in) user. A missing id
      // must NOT fall through to a scrape — that let foreign profiles
      // overwrite the logged-in account's record.
      if (!pageProfileId) {
        console.log("[UT] Skip profile scrape: could not determine profile id from URL", url);
        return;
      }
      if (pageProfileId !== data.canonicalUserId) {
        console.log("[UT] Skip profile scrape: not own profile", pageProfileId, "vs", data.canonicalUserId);
        return;
      }
      scrapeAccountWhenReady();
    });
  }

  // Scrape messages page for unread messages
  if (url.includes("/nx/messages") || url.includes("/ab/messages")) {
    scrapeMessages();
  }

  // Apply page — must check BEFORE the generic /proposals/job/ job route,
  // otherwise it would get caught by scrapeJob().
  if (url.match(/\/proposals\/job\/~[^/]+\/apply/)) {
    watchApplyPage();
    // injectAnalysisPanel();
    injectInlineSaveButton();
    return;
  }

  if (url.includes("/nx/my-stats") || url.includes("/my-stats")) {
    scrapeStats();
  } else if (url.match(/\/jobs\/~/) || url.match(/\/ab\/proposals\/job\//) || url.match(/\/nx\/proposals\/job\//)) {
    scrapeJob();
  } else if (url.match(/\/nx\/proposals\/interview\/uid\/\d+/) || url.match(/\/ab\/proposals\/interview\/uid\/\d+/)) {
    scrapeProposalDetail();
  } else if (url.match(/\/nx\/proposals\/\d+/) || url.match(/\/ab\/proposals\/\d+/)) {
    scrapeProposalDetail();
  } else if (url.includes("/nx/proposals") || url.includes("/ab/proposals")) {
    scrapeProposals();
  } else if (isFeedPage(url)) {
    scrapeFeed();
    // Also check if a job detail panel is open on the feed page
    if (isJobPanelOpen()) {
      const jobUrl = findJobUrl(findJobContainer());
      if (jobUrl && jobUrl !== lastJobPanelUrl) {
        lastJobPanelUrl = jobUrl;
        scrapedJobUrls.add(jobUrl);
        scrapeJob();
      }
    }
  }
}

// ── Watch for job panel opening on feed page (clicking a job card) ──
let panelObserverStarted = false;
function watchForJobPanel() {
  if (panelObserverStarted) return;
  panelObserverStarted = true;

  // Watch for DOM changes that indicate a job panel opened or closed
  const observer = new MutationObserver(() => {
    if (!isContextValid()) { observer.disconnect(); return; }
    try {
      if (isJobPanelOpen()) {
        const jobUrl = findJobUrl(findJobContainer());
        if (jobUrl && jobUrl !== lastJobPanelUrl) {
          console.log("[UT] Job panel detected, scraping:", jobUrl);
          lastJobPanelUrl = jobUrl;
          scrapedJobUrls.add(jobUrl);
          setTimeout(() => {
            try { scrapeJob(); }
            catch (e) { console.error("[UT] scrapeJob threw:", e); }
          }, 3500);
        }
      } else if (lastJobPanelUrl !== null) {
        lastJobPanelUrl = null;
        document.getElementById("ut-criteria-panel")?.remove();
      }
    } catch (e) {
      console.error("[UT] panel observer threw:", e);
    }
  });

  observer.observe(document.body, { childList: true, subtree: true });

  // Safety net: panel may close mid-animation so the observer misses the transition.
  // Poll every 800 ms and remove the criteria panel if no job panel is open.
  setInterval(() => {
    if (!isContextValid()) return;
    if (document.getElementById("ut-criteria-panel") && !isJobPanelOpen()) {
      lastJobPanelUrl = null;
      document.getElementById("ut-criteria-panel")?.remove();
    }
  }, 800);
}

// ── Watch for filter changes on stats page ──
let statsObserverStarted = false;
let statsDebounceTimer = null;
function watchForStatsChanges() {
  if (statsObserverStarted) return;
  statsObserverStarted = true;
  console.log("[UT] Watching stats page for filter changes...");

  // Track the page text to detect when numbers change
  let lastStatsText = document.body.innerText.slice(0, 2000);

  const observer = new MutationObserver(() => {
    try {
      const currentText = document.body.innerText.slice(0, 2000);
      if (currentText !== lastStatsText) {
        lastStatsText = currentText;
        clearTimeout(statsDebounceTimer);
        statsDebounceTimer = setTimeout(() => {
          try {
            console.log("[UT] Stats page content changed, re-scraping...");
            scrapeStats();
          } catch (e) { console.error("[UT] scrapeStats threw:", e); }
        }, 2000);
      }
    } catch (e) {
      console.error("[UT] stats observer threw:", e);
    }
  });

  observer.observe(document.body, { childList: true, subtree: true });
}

// ── Watch for pagination changes on proposals page ──
let proposalObserverStarted = false;
let proposalDebounceTimer = null;
let lastProposalPageText = "";
function watchForProposalPageChanges() {
  if (proposalObserverStarted) return;
  proposalObserverStarted = true;
  console.log("[UT] Watching proposals page for pagination changes...");

  lastProposalPageText = document.body.innerText.slice(0, 2000);

  const observer = new MutationObserver(() => {
    try {
      const currentText = document.body.innerText.slice(0, 2000);
      if (currentText !== lastProposalPageText) {
        lastProposalPageText = currentText;
        clearTimeout(proposalDebounceTimer);
        proposalDebounceTimer = setTimeout(() => {
          try {
            console.log("[UT] Proposals page content changed, re-scraping...");
            scrapeProposals();
          } catch (e) { console.error("[UT] scrapeProposals threw:", e); }
        }, 2000);
      }
    } catch (e) {
      console.error("[UT] proposals observer threw:", e);
    }
  });

  observer.observe(document.body, { childList: true, subtree: true });
}

// ── Watch for new messages on messages page ──
let messageObserverStarted = false;
let messageDebounceTimer = null;
let lastMessagePageText = "";
function watchForNewMessages() {
  if (messageObserverStarted) return;
  messageObserverStarted = true;
  console.log("[UT] Watching messages page for new messages...");

  lastMessagePageText = document.body.innerText.slice(0, 3000);

  const observer = new MutationObserver(() => {
    try {
      const currentText = document.body.innerText.slice(0, 3000);
      if (currentText !== lastMessagePageText) {
        lastMessagePageText = currentText;
        clearTimeout(messageDebounceTimer);
        messageDebounceTimer = setTimeout(() => {
          try {
            console.log("[UT] Messages page content changed, re-scraping...");
            scrapeMessages();
          } catch (e) { console.error("[UT] scrapeMessages threw:", e); }
        }, 2000);
      }
    } catch (e) {
      console.error("[UT] messages observer threw:", e);
    }
  });

  observer.observe(document.body, { childList: true, subtree: true });
}

// ── Guard against invalidated extension context (e.g. after extension reload) ──
function isContextValid() {
  try { return !!chrome.runtime?.id; } catch (_) { return false; }
}

// ── Run with delay for DOM to settle ──
function runWithDelay(delayMs = 3000) {
  setTimeout(() => {
    if (!isContextValid()) return;
    try { detectPageAndScrape(); }
    catch (e) { console.error("[UT] detectPageAndScrape threw:", e); }
    const url = window.location.href;
    try {
      if (isFeedPage(url)) {
        watchForJobPanel();
        watchForFeedCardVerdicts();
      }
      if (url.includes("/nx/my-stats") || url.includes("/my-stats")) {
        watchForStatsChanges();
      }
      if (url.includes("/nx/proposals") && !url.match(/\/nx\/proposals\/\d+/)) {
        watchForProposalPageChanges();
      }
      if (url.includes("/nx/messages") || url.includes("/ab/messages")) {
        watchForNewMessages();
      }
    } catch (e) {
      console.error("[UT] watcher setup threw:", e);
    }
  }, delayMs);
}

function maybeWatchApplyPage(url) {
  if (url.match(/\/proposals\/job\/~[^/]+\/apply/)) {
    watchApplyPage();
  }
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", () => {
    maybeWatchApplyPage(window.location.href);
    runWithDelay();
  });
} else {
  maybeWatchApplyPage(window.location.href);
  runWithDelay();
}

// ── Detect SPA navigation ──
let lastUrl = window.location.href;
const navObserver = new MutationObserver(() => {
  if (!isContextValid()) { navObserver.disconnect(); return; }
  try {
    if (window.location.href !== lastUrl) {
      console.log("[UT] SPA navigation:", window.location.href);
      lastUrl = window.location.href;
      lastJobPanelUrl = null;
      _cardVerdictObserverStarted = false;
      _cardCriteriaTs   = 0; // force criteria re-check on next page
      _cardCriteriaHash = "";
      clearTimeout(_profileScrapeTimer); // cancel any pending profile retry
      _profileScrapeAttempt = 0;
      document.getElementById("ut-criteria-panel")?.remove();
      maybeWatchApplyPage(window.location.href);
      runWithDelay(2000);
    }
  } catch (e) {
    console.error("[UT] navObserver threw:", e);
  }
});
if (document.body) {
  navObserver.observe(document.body, { childList: true, subtree: true });
}

window.addEventListener("popstate", () => {
  setTimeout(() => {
    if (window.location.href !== lastUrl) {
      lastUrl = window.location.href;
      maybeWatchApplyPage(window.location.href);
      runWithDelay(1500);
    }
  }, 1000);
});

console.log("[UT] Content script ready — active scraping enabled");

window.addEventListener("error", (ev) => {
  console.error("[UT] uncaught error:", ev?.message, ev?.error);
});
window.addEventListener("unhandledrejection", (ev) => {
  console.error("[UT] unhandled rejection:", ev?.reason);
});

function safe(fn, name) {
  return (...args) => {
    try { return fn(...args); }
    catch (e) { console.error(`[UT] ${name || fn.name || "fn"} threw:`, e); }
  };
}

// ── Coverage modal ──
function showCoverageModal({ pct, unvisited }) {
  document.getElementById("ut-coverage-modal")?.remove();

  const overlay = document.createElement("div");
  overlay.id = "ut-coverage-modal";
  overlay.style.cssText = `
    position: fixed; inset: 0; background: rgba(0,0,0,0.5);
    z-index: 2147483647; display: flex; align-items: center; justify-content: center;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  `;

  const pages = unvisited.map((p) => `
    <div style="display:flex;align-items:center;justify-content:space-between;padding:10px 14px;background:#fef3f2;border:1px solid #fecaca;border-radius:10px;">
      <span style="font-size:14px;color:#111827;font-weight:500;">${p.name}</span>
      <a href="${p.url}" target="_blank" rel="noopener noreferrer"
         style="font-size:12px;font-weight:600;color:#fff;background:#14b8a6;padding:5px 12px;border-radius:6px;text-decoration:none;">
        Open
      </a>
    </div>
  `).join("");

  overlay.innerHTML = `
    <div style="background:#fff;border-radius:16px;box-shadow:0 25px 50px rgba(0,0,0,0.25);max-width:420px;width:90%;padding:24px;">
      <div style="display:flex;align-items:flex-start;gap:12px;margin-bottom:16px;">
        <div style="width:40px;height:40px;border-radius:50%;background:#fef2f2;border:1px solid #fecaca;display:flex;align-items:center;justify-content:center;flex-shrink:0;">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
            <line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>
          </svg>
        </div>
        <div>
          <div style="font-size:16px;font-weight:700;color:#111827;">Page coverage is ${pct}%</div>
          <div style="font-size:13px;color:#6b7280;margin-top:2px;">Open the pages below to keep your stats accurate.</div>
        </div>
      </div>
      <div style="display:flex;flex-direction:column;gap:8px;margin-bottom:20px;">${pages || '<p style="font-size:13px;color:#6b7280;text-align:center;">All required pages visited.</p>'}</div>
      <button id="ut-coverage-close" style="width:100%;padding:10px;background:#111827;color:#fff;border:none;border-radius:10px;font-size:14px;font-weight:600;cursor:pointer;">
        Close
      </button>
    </div>
  `;

  document.body.appendChild(overlay);
  document.getElementById("ut-coverage-close").addEventListener("click", () => overlay.remove());
  overlay.addEventListener("click", (e) => { if (e.target === overlay) overlay.remove(); });
}

chrome.runtime.onMessage.addListener((message) => {
  try {
    if (message.type === "SHOW_COVERAGE_MODAL") {
      showCoverageModal(message.payload);
    } else if (message.type === "SHOW_NUDGE_SUMMARY") {
      renderNudgeSummaryToast(message.payload || {});
    }
  } catch (e) {
    console.error("[UT] message handler threw:", e);
  }
  if (message.type === "ACCOUNT_DISABLE_STATUS") {
    if (message.isDisabled) showDisabledBanner(message.reason);
    else removeDisabledBanner();
  }
});

// On page load, check stored disable status immediately
chrome.storage.local.get(["accountDisabled", "accountDisabledReason"], (data) => {
  if (data.accountDisabled) showDisabledBanner(data.accountDisabledReason ?? null);
});

function showDisabledBanner(reason) {
  removeDisabledBanner();
  const banner = document.createElement("div");
  banner.id = "__ut_disabled_banner";
  banner.style.cssText = [
    "position:fixed",
    "top:0",
    "left:0",
    "right:0",
    "z-index:2147483647",
    "background:rgba(220,38,38,0.82)",
    "backdrop-filter:blur(6px)",
    "-webkit-backdrop-filter:blur(6px)",
    "color:#fff",
    "font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif",
    "font-size:14px",
    "font-weight:600",
    "text-align:center",
    "padding:10px 48px",
    "box-shadow:0 2px 8px rgba(0,0,0,0.3)",
    "letter-spacing:0.01em",
  ].join(";");
  const msg = reason
    ? `Bidding disabled: ${reason}`
    : "Admin has forbidden bidding on this Upwork account";
  banner.textContent = msg;

  const closeBtn = document.createElement("button");
  closeBtn.textContent = "✕";
  closeBtn.style.cssText = [
    "position:absolute",
    "right:14px",
    "top:50%",
    "transform:translateY(-50%)",
    "background:rgba(255,255,255,0.2)",
    "border:none",
    "color:#fff",
    "font-size:13px",
    "font-weight:700",
    "width:24px",
    "height:24px",
    "border-radius:50%",
    "cursor:pointer",
    "display:flex",
    "align-items:center",
    "justify-content:center",
    "line-height:1",
    "padding:0",
  ].join(";");
  closeBtn.addEventListener("click", () => removeDisabledBanner());
  banner.appendChild(closeBtn);

  document.documentElement.appendChild(banner);
}

function removeDisabledBanner() {
  const existing = document.getElementById("__ut_disabled_banner");
  if (existing) existing.remove();
}

function renderNudgeSummaryToast({ count, single, accountName }) {
  if (!count || count <= 0) return;

  const escapeHtml = (s) =>
    String(s).replace(/[<>&"']/g, (c) => (
      { "<": "&lt;", ">": "&gt;", "&": "&amp;", '"': "&quot;", "'": "&#39;" }[c]
    ));

  const safeId = "ut-nudge-summary-" + (accountName || "default").replace(/[^a-z0-9]/gi, "-").toLowerCase();
  const existing = document.getElementById(safeId);
  if (existing) existing.remove();

  // Stack below any other open nudge toasts
  const existingToasts = document.querySelectorAll('[id^="ut-nudge-summary-"]');
  const topOffset = 20 + existingToasts.length * 195;

  const t = document.createElement("div");
  t.id = safeId;
  t.style.cssText = [
    "position:fixed", `top:${topOffset}px`, "right:20px", "width:340px",
    "background:#fff7ed", "border:1px solid #fdba74", "border-radius:12px",
    "padding:14px 16px",
    "box-shadow:0 10px 30px rgba(0,0,0,0.15)",
    "z-index:2147483647",
    "font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif",
  ].join(";");

  const safeAccount = accountName ? escapeHtml(accountName) : null;
  let bodyHtml;
  let primaryUrl;

  if (count === 1 && single?.jobTitle) {
    const safeTitle = escapeHtml(single.jobTitle);
    bodyHtml = `
      <div style="color:#9a3412;font-size:11px;margin-bottom:4px;text-transform:uppercase;letter-spacing:0.04em;">Unscanned proposal${safeAccount ? ` · ${safeAccount}` : ""}</div>
      <div style="color:#1c1917;font-size:14px;font-weight:600;margin-bottom:6px;line-height:1.35;">${safeTitle}</div>
      <div style="color:#57534e;font-size:12px;margin-bottom:10px;line-height:1.4;">Open it once so the tracker captures the cover letter and job details.</div>
    `;
    primaryUrl = single.jobUrl
      ? (single.jobUrl.startsWith("http") ? single.jobUrl : `https://www.upwork.com${single.jobUrl}`)
      : "https://www.upwork.com/nx/proposals/";
  } else {
    bodyHtml = `
      <div style="color:#9a3412;font-size:11px;margin-bottom:4px;text-transform:uppercase;letter-spacing:0.04em;">${safeAccount ? `${safeAccount} · ` : ""}${count} unscanned proposal${count !== 1 ? "s" : ""}</div>
      <div style="color:#1c1917;font-size:14px;margin-bottom:10px;line-height:1.4;">
        Open each one once so the tracker captures the cover letter and job details.
      </div>
    `;
    primaryUrl = "https://www.upwork.com/nx/proposals/";
  }

  const primaryLabel = count === 1 ? "Open proposal" : "Open Proposals";

  t.innerHTML = `
    <div style="font-weight:600;color:#9a3412;font-size:13px;margin-bottom:6px;">📌 Scan reminder</div>
    ${bodyHtml}
    <div style="display:flex;gap:8px;">
      <button data-act="open" style="flex:1;background:#ea580c;color:#fff;border:0;border-radius:8px;padding:8px 10px;font-size:13px;font-weight:600;cursor:pointer;">${primaryLabel}</button>
      <button data-act="dismiss" style="background:transparent;border:1px solid #d6d3d1;border-radius:8px;padding:8px 10px;font-size:13px;color:#57534e;cursor:pointer;">Dismiss</button>
    </div>
  `;
  document.body.appendChild(t);

  t.querySelector('[data-act="open"]').onclick = () => {
    window.open(primaryUrl, "_blank");
    chrome.runtime.sendMessage({ type: "ACK_ALL_NUDGES" }, () => {});
    t.remove();
  };
  t.querySelector('[data-act="dismiss"]').onclick = () => {
    t.remove();
  };
}

